'use strict';

// Pure Spades rules. No networking in here, so it can be unit tested.
// Cards are 2-character strings: rank + suit, e.g. "AS" (ace of spades), "TH" (ten of hearts).
// Seats: 0 = North, 1 = East, 2 = South, 3 = West. Play goes clockwise (0 -> 1 -> 2 -> 3).
// Teams: team 0 = North + South (seats 0, 2), team 1 = East + West (seats 1, 3).

const crypto = require('crypto');

const SUITS = ['S', 'H', 'C', 'D']; // hand sort order (alternates colours)
const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'];
const MERCY_SCORE = -200;
const HAND_SIZE = 13;

class GameError extends Error {}

const suitOf = (card) => card[1];
const rankOf = (card) => RANKS.indexOf(card[0]) + 2; // 2..14
const teamOf = (seat) => seat % 2;
const nextSeat = (seat) => (seat + 1) % 4;
const isCard = (c) => typeof c === 'string' && c.length === 2 && RANKS.includes(c[0]) && SUITS.includes(c[1]);

function newDeck() {
  const deck = [];
  for (const s of SUITS) for (const r of RANKS) deck.push(r + s);
  return deck;
}

const defaultRandInt = (n) => crypto.randomInt(n);

function shuffle(cards, randInt = defaultRandInt) {
  const a = cards.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function sortHand(hand) {
  return hand
    .slice()
    .sort((a, b) => SUITS.indexOf(suitOf(a)) - SUITS.indexOf(suitOf(b)) || rankOf(b) - rankOf(a));
}

function deal(randInt = defaultRandInt) {
  const deck = shuffle(newDeck(), randInt);
  return [0, 1, 2, 3].map((i) => sortHand(deck.slice(i * HAND_SIZE, (i + 1) * HAND_SIZE)));
}

/** Cards from `hand` that may legally be played onto `trick` ([{seat, card}]). */
function legalPlays(hand, trick, spadesBroken) {
  if (trick.length === 0) {
    if (spadesBroken) return hand.slice();
    const nonSpades = hand.filter((c) => suitOf(c) !== 'S');
    return nonSpades.length ? nonSpades : hand.slice();
  }
  const led = suitOf(trick[0].card);
  const follow = hand.filter((c) => suitOf(c) === led);
  return follow.length ? follow : hand.slice();
}

/** Does card `a` beat the currently winning card `b`? */
function beats(a, b) {
  if (suitOf(a) === suitOf(b)) return rankOf(a) > rankOf(b);
  return suitOf(a) === 'S'; // a trump beats any non-trump; an off-suit card never wins
}

/** Seat that wins a trick ([{seat, card}], first entry is the lead). */
function trickWinner(trick) {
  let best = trick[0];
  for (const p of trick.slice(1)) if (beats(p.card, best.card)) best = p;
  return best.seat;
}

/**
 * Scoring units: 2 teams (North+South, East+West) or 4 players on their own.
 */
const unitsFor = (teams) => (teams ? [[0, 2], [1, 3]] : [[0], [1], [2], [3]]);

/**
 * Score one hand for every unit (team or single player).
 * - Contract (sum of non-Nil bids) made: +10 per bid trick, +1 per overtrick (bag).
 * - Contract missed: -10 per bid trick.
 * - Nil: +100 if the Nil bidder took no tricks, else -100. Their tricks never help the
 *   partner's contract, but they count as bags (+1 each).
 * - Bag penalty (optional): every 10 accumulated bags costs 100 points.
 */
function scoreHand({ bids, tricks, scores, bags, settings, units }) {
  const list = units || unitsFor(settings.teams !== false);
  return list.map((seats, unit) => {
    let points = 0;
    let newBags = 0;
    let contract = 0;
    let contractTricks = 0;
    const nils = [];
    for (const s of seats) {
      if (bids[s] === 0) {
        const made = tricks[s] === 0;
        points += made ? 100 : -100;
        newBags += tricks[s];
        nils.push({ seat: s, made });
      } else {
        contract += bids[s];
        contractTricks += tricks[s];
      }
    }
    let made = null; // null = no contract (everyone in the unit bid Nil)
    if (contract > 0) {
      made = contractTricks >= contract;
      if (made) {
        points += 10 * contract;
        newBags += contractTricks - contract;
      } else {
        points -= 10 * contract;
      }
    }
    points += newBags;
    let totalBags = bags[unit] + newBags;
    let bagPenalty = 0;
    if (settings.bagPenalty) {
      while (totalBags >= 10) {
        totalBags -= 10;
        bagPenalty += 100;
      }
    }
    points -= bagPenalty;
    return {
      unit,
      seats,
      bid: contract,
      tricks: seats.reduce((sum, s) => sum + tricks[s], 0),
      contractTricks,
      made,
      nils,
      newBags,
      bagPenalty,
      points,
      score: scores[unit] + points,
      bags: totalBags,
    };
  });
}

/**
 * Winning unit index, or null if the game goes on. The game ends when someone reaches the
 * target or someone falls to the mercy score; the single highest score wins. A tie for the
 * lead plays another hand.
 */
function checkWinner(scores, target) {
  const max = Math.max(...scores);
  const min = Math.min(...scores);
  if (max < target && min > MERCY_SCORE) return null;
  const leaders = scores.map((s, i) => [s, i]).filter(([s]) => s === max);
  return leaders.length === 1 ? leaders[0][1] : null;
}

const SUIT_WORD = { S: 'spades', H: 'hearts', C: 'clubs', D: 'diamonds' };

class SpadesGame {
  /**
   * @param {{target:number, nil:boolean, bagPenalty:boolean, teams:boolean}} settings
   * @param {{randInt?:(n:number)=>number, dealer?:number}} [opts]
   */
  constructor(settings, opts = {}) {
    this.settings = { target: 500, nil: true, bagPenalty: true, teams: true, ...settings };
    this.randInt = opts.randInt || defaultRandInt;
    this.units = unitsFor(this.settings.teams);
    this.scores = this.units.map(() => 0);
    this.bags = this.units.map(() => 0);
    this.history = [];
    this.handNumber = 0;
    this.dealer = opts.dealer ?? this.randInt(4);
    this.winner = null;
    this.startHand();
  }

  startHand() {
    this.handNumber += 1;
    if (this.handNumber > 1) this.dealer = nextSeat(this.dealer);
    this.hands = deal(this.randInt);
    this.bids = [null, null, null, null];
    this.tricksWon = [0, 0, 0, 0];
    this.trick = [];
    this.trickWinner = null; // set while a finished trick waits to be collected
    this.lastTrick = null;
    this.spadesBroken = false;
    this.turn = nextSeat(this.dealer);
    this.phase = 'bidding';
    this.lastHandResult = null;
  }

  placeBid(seat, bid) {
    if (this.phase !== 'bidding') throw new GameError('Bidding is over.');
    if (seat !== this.turn) throw new GameError("It's not your turn to bid.");
    if (!Number.isInteger(bid) || bid < 0 || bid > HAND_SIZE) throw new GameError('Bid must be 0 to 13.');
    if (bid === 0 && !this.settings.nil) throw new GameError('Nil bids are turned off for this game.');
    this.bids[seat] = bid;
    if (this.bids.every((b) => b !== null)) {
      this.phase = 'playing';
      this.turn = nextSeat(this.dealer);
    } else {
      this.turn = nextSeat(seat);
    }
  }

  legalFor(seat) {
    if (this.phase !== 'playing' || seat !== this.turn || this.trickWinner !== null) return [];
    return legalPlays(this.hands[seat], this.trick, this.spadesBroken);
  }

  /** Returns true when this card completed the trick (call collectTrick() afterwards). */
  playCard(seat, card) {
    if (this.phase !== 'playing') throw new GameError('Cards cannot be played right now.');
    if (this.trickWinner !== null) throw new GameError('Wait for the trick to be collected.');
    if (seat !== this.turn) throw new GameError("It's not your turn.");
    const hand = this.hands[seat];
    if (!hand.includes(card)) throw new GameError("You don't have that card.");
    if (!legalPlays(hand, this.trick, this.spadesBroken).includes(card)) {
      if (this.trick.length === 0) throw new GameError("Spades aren't broken yet. Lead another suit.");
      throw new GameError(`You must follow suit (${SUIT_WORD[suitOf(this.trick[0].card)]}).`);
    }
    hand.splice(hand.indexOf(card), 1);
    this.trick.push({ seat, card });
    if (suitOf(card) === 'S') this.spadesBroken = true;
    if (this.trick.length === 4) {
      this.trickWinner = trickWinner(this.trick);
      this.turn = null;
      return true;
    }
    this.turn = nextSeat(seat);
    return false;
  }

  collectTrick() {
    if (this.trickWinner === null) throw new GameError('No finished trick to collect.');
    const winner = this.trickWinner;
    this.tricksWon[winner] += 1;
    this.lastTrick = { cards: this.trick, winner };
    this.trick = [];
    this.trickWinner = null;
    if (this.hands.every((h) => h.length === 0)) this.finishHand();
    else this.turn = winner;
  }

  finishHand() {
    const units = scoreHand({
      bids: this.bids,
      tricks: this.tricksWon,
      scores: this.scores,
      bags: this.bags,
      settings: this.settings,
      units: this.units,
    });
    for (const u of units) {
      this.scores[u.unit] = u.score;
      this.bags[u.unit] = u.bags;
    }
    this.lastHandResult = {
      handNumber: this.handNumber,
      bids: this.bids.slice(),
      tricks: this.tricksWon.slice(),
      units,
    };
    this.history.push({
      handNumber: this.handNumber,
      points: units.map((u) => u.points),
      scores: this.scores.slice(),
    });
    this.turn = null;
    this.winner = checkWinner(this.scores, this.settings.target);
    this.phase = this.winner === null ? 'handOver' : 'gameOver';
  }

  nextHand() {
    if (this.phase !== 'handOver') throw new GameError('The hand is not over yet.');
    this.startHand();
  }

  /** Everything except the hands. Safe to send to every screen. */
  publicState() {
    return {
      phase: this.phase,
      settings: this.settings,
      units: this.units,
      dealer: this.dealer,
      handNumber: this.handNumber,
      turn: this.turn,
      bids: this.bids,
      tricksWon: this.tricksWon,
      trick: this.trick,
      trickWinner: this.trickWinner,
      lastTrick: this.lastTrick,
      spadesBroken: this.spadesBroken,
      scores: this.scores,
      bags: this.bags,
      handSizes: this.hands.map((h) => h.length),
      lastHandResult: this.lastHandResult,
      history: this.history,
      winner: this.winner,
    };
  }
}

module.exports = {
  SUITS,
  RANKS,
  MERCY_SCORE,
  GameError,
  SpadesGame,
  suitOf,
  rankOf,
  teamOf,
  nextSeat,
  isCard,
  newDeck,
  shuffle,
  sortHand,
  deal,
  legalPlays,
  beats,
  trickWinner,
  scoreHand,
  checkWinner,
  unitsFor,
};
