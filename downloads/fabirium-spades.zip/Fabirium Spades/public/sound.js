/* Background music and sound effects, made live with the Web Audio API (no audio files).
 * Browsers only allow sound after the first tap, so everything unlocks on the first touch. */
(function () {
  'use strict';

  const store = window.Spades.store;
  let ctx = null;
  let musicGain = null;
  let sfxGain = null;
  let noiseBuf = null;
  let unlocked = false;
  let musicOn = false; // the player's choice
  let musicAllowed = true; // false on a phone in an iPad game: the iPad plays the music
  let sfxOn = true;
  let musicKey = 'spades.music';
  let sfxKey = 'spades.sfx';
  let playing = false;
  let timer = null;
  let nextTime = 0;
  let step = 0;
  let melodyIdx = 3;
  const listeners = [];

  const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
  const emit = () => listeners.forEach((fn) => fn());

  // ---------- audio graph ----------
  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      ctx = new AC();
    } catch (e) {
      return null;
    }
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.ratio.value = 3;
    comp.connect(ctx.destination);

    const verb = ctx.createConvolver();
    verb.buffer = impulse(2.8);
    const verbOut = ctx.createGain();
    verbOut.gain.value = 0.6;
    verb.connect(verbOut);
    verbOut.connect(comp);

    musicGain = ctx.createGain();
    musicGain.gain.value = 0;
    musicGain.connect(comp);
    const musicSend = ctx.createGain();
    musicSend.gain.value = 0.45;
    musicGain.connect(musicSend);
    musicSend.connect(verb);

    sfxGain = ctx.createGain();
    sfxGain.gain.value = 0.85;
    sfxGain.connect(comp);
    const sfxSend = ctx.createGain();
    sfxSend.gain.value = 0.25;
    sfxGain.connect(sfxSend);
    sfxSend.connect(verb);

    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return ctx;
  }

  function impulse(seconds) {
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    }
    return buf;
  }

  function unlock() {
    if (!ensure()) return;
    const wasUnlocked = unlocked;
    try {
      if (navigator.audioSession) navigator.audioSession.type = 'playback'; // iOS: play even in silent mode
    } catch (e) {
      /* older Safari */
    }
    resume();
    if (!unlocked) {
      // iOS needs a sound started inside the tap itself.
      const src = ctx.createBufferSource();
      src.buffer = ctx.createBuffer(1, 1, 22050);
      src.connect(ctx.destination);
      src.start(0);
      unlocked = true;
    }
    if (musicOn && musicAllowed && !playing) startMusic();
    // Redraw the sound buttons only the first time, and only after this tap has finished:
    // redrawing in the middle of a tap on the Music switch would undo the tap.
    if (!wasUnlocked) setTimeout(emit, 0);
  }
  ['pointerdown', 'touchend', 'click', 'keydown'].forEach((ev) =>
    document.addEventListener(ev, unlock, { capture: true, passive: true }),
  );
  function resume() {
    if (!ctx || ctx.state === 'running' || !ctx.resume) return;
    const p = ctx.resume();
    if (p && p.catch) p.catch(() => {});
  }
  document.addEventListener('visibilitychange', () => {
    if (unlocked && document.visibilityState === 'visible') resume();
  });

  // ---------- instruments ----------
  function env(g, t, peak, attack, release) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0002), t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + release);
  }

  function osc(type, freq, t, stopAt, dest, detune) {
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (detune) o.detune.value = detune;
    o.connect(dest);
    o.start(t);
    o.stop(stopAt);
    return o;
  }

  /** Soft electric-piano chord note. */
  function keys(m, t, vel, len) {
    const g = ctx.createGain();
    env(g, t, 0.07 * vel, 0.012, len);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 2000;
    lp.connect(g);
    g.connect(musicGain);
    const f = mtof(m);
    osc('sine', f, t, t + len + 0.1, lp);
    const bell = ctx.createGain();
    bell.gain.value = 0.16;
    bell.connect(lp);
    osc('triangle', f * 2, t, t + len + 0.1, bell, 5);
  }

  function bass(m, t, vel, len) {
    const g = ctx.createGain();
    env(g, t, 0.2 * vel, 0.015, len);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 380;
    lp.connect(g);
    g.connect(musicGain);
    osc('triangle', mtof(m), t, t + len + 0.1, lp);
  }

  function kick(t, vel) {
    const g = ctx.createGain();
    env(g, t, 0.42 * vel, 0.004, 0.3);
    g.connect(musicGain);
    const o = osc('sine', 110, t, t + 0.4, g);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
  }

  function noise(t, len, filterType, freq, q, peak, dest) {
    const src = ctx.createBufferSource();
    src.buffer = noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = filterType;
    f.frequency.setValueAtTime(freq, t);
    f.Q.value = q;
    const g = ctx.createGain();
    env(g, t, peak, 0.004, len);
    src.connect(f);
    f.connect(g);
    g.connect(dest);
    src.start(t, Math.random() * 0.5, len + 0.05);
    return f;
  }

  function bellNote(m, t, peak, len, dest) {
    const g = ctx.createGain();
    env(g, t, peak, 0.005, len);
    g.connect(dest);
    osc('sine', mtof(m), t, t + len + 0.1, g);
    const shimmer = ctx.createGain();
    shimmer.gain.value = 0.12;
    shimmer.connect(g);
    osc('sine', mtof(m) * 2.76, t, t + len * 0.5, shimmer);
  }

  // ---------- music: a slow lo-fi loop in F ----------
  const BPM = 78;
  const EIGHTH = 60 / BPM / 2;
  const BARS = [
    { root: 41, chord: [57, 60, 64, 67] }, // Fmaj9
    { root: 40, chord: [55, 59, 62, 64] }, // Em7
    { root: 38, chord: [53, 57, 60, 64] }, // Dm9
    { root: 36, chord: [52, 55, 59, 62] }, // Cmaj9
  ];
  const SCALE = [65, 67, 69, 72, 74, 76, 77, 79, 81]; // F pentatonic-ish, upper octave

  function playStep(s, t) {
    const bar = BARS[Math.floor(s / 8) % BARS.length];
    const next = BARS[(Math.floor(s / 8) + 1) % BARS.length];
    const e = s % 8;
    const beat = EIGHTH * 2;

    if (e === 0) bar.chord.forEach((m, i) => keys(m, t + i * 0.012, 1, beat * 2.6));
    if (e === 3) bar.chord.forEach((m) => keys(m, t, 0.5, beat * 1.4));
    if (e === 6 && Math.random() < 0.6) bar.chord.slice(1).forEach((m) => keys(m, t, 0.4, beat));

    if (e === 0) bass(bar.root, t, 1, beat * 1.6);
    if (e === 3) bass(bar.root + 7, t, 0.7, beat * 0.8);
    if (e === 6) bass(bar.root + 12, t, 0.6, beat * 0.6);
    if (e === 7) bass(next.root + 2, t, 0.45, beat * 0.4);

    if (e === 0 || e === 3) kick(t, e === 0 ? 1 : 0.7);
    if (e === 2 || e === 6) noise(t, 0.16, 'bandpass', 1900, 0.8, 0.07, musicGain); // soft snare
    noise(t, 0.045, 'highpass', 7600, 0.7, e % 2 ? 0.018 : 0.03, musicGain); // hat

    if (Math.random() < (e % 2 ? 0.14 : 0.3)) {
      melodyIdx = Math.max(0, Math.min(SCALE.length - 1, melodyIdx + [-2, -1, -1, 1, 1, 2][Math.floor(Math.random() * 6)]));
      bellNote(SCALE[melodyIdx], t, 0.035, 1.6, musicGain);
    }
  }

  function schedule() {
    if (!ctx) return;
    const now = ctx.currentTime;
    if (nextTime < now - 0.2) nextTime = now + 0.05; // tab was asleep: skip ahead, don't burst
    while (nextTime < now + 0.3) {
      const swing = step % 2 ? EIGHTH * 0.18 : 0;
      try {
        playStep(step, nextTime + swing);
      } catch (e) {
        /* ignore a dropped note */
      }
      nextTime += EIGHTH;
      step = (step + 1) % 32;
    }
  }

  function startMusic() {
    if (playing || !ctx || !unlocked || !musicAllowed) return;
    playing = true;
    step = 0;
    nextTime = ctx.currentTime + 0.1;
    const t = ctx.currentTime;
    musicGain.gain.cancelScheduledValues(t);
    musicGain.gain.setValueAtTime(musicGain.gain.value, t);
    musicGain.gain.linearRampToValueAtTime(0.85, t + 2);
    timer = setInterval(schedule, 60);
    schedule();
  }

  function stopMusic() {
    if (!playing) return;
    playing = false;
    clearInterval(timer);
    timer = null;
    const t = ctx.currentTime;
    musicGain.gain.cancelScheduledValues(t);
    musicGain.gain.setValueAtTime(musicGain.gain.value, t);
    musicGain.gain.linearRampToValueAtTime(0, t + 0.6);
  }

  // ---------- sound effects ----------
  function swish(t, len, from, to, peak) {
    const f = noise(t, len, 'bandpass', from, 1.1, peak, sfxGain);
    f.frequency.exponentialRampToValueAtTime(to, t + len);
  }

  const EFFECTS = {
    card(t) {
      swish(t, 0.16, 900, 3400, 0.4);
      const g = ctx.createGain();
      env(g, t + 0.12, 0.22, 0.003, 0.09);
      g.connect(sfxGain);
      const o = osc('sine', 170, t + 0.12, t + 0.3, g);
      o.frequency.exponentialRampToValueAtTime(80, t + 0.2);
    },
    sweep(t) {
      swish(t, 0.38, 3200, 600, 0.26);
    },
    deal(t) {
      for (let i = 0; i < 10; i++) swish(t + i * 0.065, 0.08, 1400, 3600, 0.16);
    },
    win(t) {
      [76, 83, 88].forEach((m, i) => bellNote(m, t + i * 0.1, 0.16, 1.2, sfxGain));
    },
    turn(t) {
      bellNote(79, t, 0.14, 0.9, sfxGain);
      bellNote(84, t + 0.13, 0.14, 1.1, sfxGain);
    },
    bid(t) {
      bellNote(91, t, 0.06, 0.25, sfxGain);
    },
    handOver(t) {
      [72, 76, 79].forEach((m, i) => bellNote(m, t + i * 0.12, 0.13, 1.4, sfxGain));
    },
    gameOver(t) {
      [72, 76, 79, 84].forEach((m, i) => bellNote(m, t + i * 0.14, 0.15, 1.8, sfxGain));
      [60, 64, 67, 72].forEach((m) => bellNote(m, t + 0.62, 0.08, 2.4, sfxGain));
    },
    alert(t) {
      bellNote(81, t, 0.12, 0.5, sfxGain);
      bellNote(76, t + 0.18, 0.12, 0.8, sfxGain);
    },
  };

  function play(name) {
    if (!sfxOn || !ctx || !unlocked || !EFFECTS[name]) return;
    try {
      EFFECTS[name](ctx.currentTime + 0.01);
    } catch (e) {
      /* never let sound break the game */
    }
  }

  // ---------- settings ----------
  function setMusic(on, persist) {
    musicOn = !!on;
    if (persist !== false) store.set(musicKey, musicOn ? '1' : '0');
    if (musicOn) startMusic();
    else stopMusic();
    emit();
  }

  function setSfx(on, persist) {
    sfxOn = !!on;
    if (persist !== false) store.set(sfxKey, sfxOn ? '1' : '0');
    emit();
  }

  /**
   * Defaults for this screen, unless the player already chose. The iPad and the phones
   * remember their choices separately (`scope`).
   */
  function setup(defaults) {
    const scope = defaults.scope ? '.' + defaults.scope : '';
    musicKey = 'spades.music' + scope;
    sfxKey = 'spades.sfx' + scope;
    const m = store.get(musicKey);
    const s = store.get(sfxKey);
    musicOn = m === null ? !!defaults.music : m === '1';
    sfxOn = s === null ? true : s === '1';
  }

  /** Whether this screen may play music at all. Off for phones in an iPad game. */
  function allowMusic(on) {
    if (musicAllowed === !!on) return;
    musicAllowed = !!on;
    if (!musicAllowed) stopMusic();
    else if (musicOn) startMusic();
    emit();
  }

  const status = () => ({ unlocked, musicOn, musicAllowed, musicPlaying: playing, sfxOn });

  /**
   * A speaker button with a small menu: Music / Sound effects.
   * opts.label adds a word to the button; opts.align 'left' opens the menu to the right of a left-edge button.
   */
  function mountButton(container, opts) {
    const label = opts && opts.label ? ' Sound' : '';
    const wrap = document.createElement('div');
    wrap.className = 'sound-wrap' + (opts && opts.align === 'left' ? ' left' : '');
    wrap.innerHTML =
      '<button class="sound-btn" type="button" aria-haspopup="true" aria-label="Sound settings"></button>' +
      '<div class="sound-pop hidden" role="menu">' +
      '<label class="sound-row" data-row="music"><span>Music</span><span class="switch"><input type="checkbox" data-k="music"><span></span></span></label>' +
      '<p class="sound-note hidden" data-row="music-note">🎵 The music plays on the iPad.</p>' +
      '<label class="sound-row"><span>Sound effects</span><span class="switch"><input type="checkbox" data-k="sfx"><span></span></span></label>' +
      '<p class="sound-hint">No sound on iPhone or iPad? Turn off silent mode.</p>' +
      '</div>';
    container.appendChild(wrap);
    const btn = wrap.querySelector('.sound-btn');
    const pop = wrap.querySelector('.sound-pop');
    const musicRow = wrap.querySelector('[data-row="music"]');
    const musicNote = wrap.querySelector('[data-row="music-note"]');
    const musicBox = wrap.querySelector('[data-k="music"]');
    const sfxBox = wrap.querySelector('[data-k="sfx"]');
    const refresh = () => {
      const on = (musicOn && musicAllowed) || sfxOn;
      const waiting = on && !unlocked;
      btn.textContent = waiting ? '🔈 Tap for sound' : (on ? '🔊' : '🔇') + label;
      btn.classList.toggle('waiting', waiting);
      musicRow.classList.toggle('hidden', !musicAllowed);
      musicNote.classList.toggle('hidden', musicAllowed);
      musicBox.checked = musicOn;
      sfxBox.checked = sfxOn;
    };
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      pop.classList.toggle('hidden');
    });
    pop.addEventListener('click', (e) => e.stopPropagation());
    document.addEventListener('click', () => pop.classList.add('hidden'));
    musicBox.addEventListener('change', () => setMusic(musicBox.checked));
    sfxBox.addEventListener('change', () => setSfx(sfxBox.checked));
    listeners.push(refresh);
    refresh();
  }

  window.Sound = { play, setup, setMusic, setSfx, allowMusic, status, mountButton, unlock };
})();
