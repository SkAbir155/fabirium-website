'use strict';

const path = require('path');
const http = require('http');
const os = require('os');
const express = require('express');
const { Server } = require('socket.io');
const QRCode = require('qrcode');
const { RoomManager } = require('./rooms');
const { registerHandlers, broadcast } = require('./handlers');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');

/**
 * Build the app without starting it (the simulation test starts its own copy).
 * @param {{botDelayMs?:number, trickPauseMs?:number, gameOpts?:object}} [opts]
 */
function createServer(opts = {}) {
  const botDelayMs = opts.botDelayMs ?? 900;
  const trickPauseMs = opts.trickPauseMs ?? 1600;

  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, { pingInterval: 10000, pingTimeout: 8000 });

  const rooms = new RoomManager({ botDelayMs, trickPauseMs, gameOpts: opts.gameOpts, onChange: broadcast });

  app.disable('x-powered-by');
  app.get('/healthz', (req, res) => res.type('text').send('ok'));
  app.get('/table', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'table.html')));
  app.get('/play', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'player.html')));
  app.get('/qr.svg', async (req, res) => {
    const data = String(req.query.data || '');
    if (!data || data.length > 300) return res.status(400).type('text').send('bad data');
    try {
      const svg = await QRCode.toString(data, { type: 'svg', margin: 1, errorCorrectionLevel: 'M' });
      res.type('image/svg+xml').set('Cache-Control', 'public, max-age=86400').send(svg);
    } catch (err) {
      res.status(500).end();
    }
  });
  app.use(express.static(PUBLIC_DIR, { extensions: ['html'] }));

  io.on('connection', (socket) => registerHandlers(socket, rooms));

  return {
    app,
    server,
    io,
    rooms,
    close() {
      rooms.close();
      io.close();
      server.close();
    },
  };
}

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
  }
  return out;
}

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  const { server } = createServer();
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`\n  Fabirium Spades can't start: port ${port} is already in use.`);
      console.error('  The game (or another program) is probably already running in another window.');
      console.error('  Close that window and try again. If that does not help, restart the computer.\n');
      process.exit(1);
    }
    throw err;
  });
  server.listen(port, () => {
    console.log(`Fabirium Spades is running on http://localhost:${port}`);
    for (const ip of lanAddresses()) console.log(`  Same Wi-Fi devices: http://${ip}:${port}`);
  });
}

module.exports = { createServer };
