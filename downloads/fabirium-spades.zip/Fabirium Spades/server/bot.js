'use strict';

// A simple computer player. Good enough to fill an empty seat, not a champion.

const { suitOf, rankOf, legalPlays, trickWinner, beats } = require('./game');

const has = (ranks, r) => ranks.includes(r);

/** Estimate how many tricks this hand will take. Bots never bid Nil. */
function botBid(hand) {
  const bySuit = { S: [], H: [], C: [], D: [] };
  for (const c of hand) bySuit[suitOf(c)].push(rankOf(c));
  const spades = bySuit.S;
  let est = 0;

  if (has(spades, 14)) est += 1;
  if (has(spades, 13)) est += spades.length >= 2 ? 1 : 0.5;
  if (has(spades, 12)) est += spades.length >= 3 ? 1 : 0.3;
  if (has(spades, 11) && spades.length >= 4) est += 0.5;
  est += Math.max(0, spades.length - 3) * 0.9; // long trumps take late tricks

  for (const s of ['H', 'C', 'D']) {
    const ranks = bySuit[s];
    if (has(ranks, 14)) est += ranks.length <= 5 ? 1 : 0.7;
    if (has(ranks, 13) && ranks.length >= 2) est += ranks.length <= 4 ? 0.8 : 0.5;
    if (has(ranks, 12) && ranks.length >= 3 && ranks.length <= 4) est += 0.3;
    if (spades.length >= 2) {
      if (ranks.length === 0) est += 0.8; // void: can trump
      else if (ranks.length === 1) est += 0.4;
    }
  }
  return Math.max(1, Math.min(13, Math.round(est)));
}

// Lower value = cheaper to throw away. Spades are kept back when possible.
const cost = (c) => rankOf(c) + (suitOf(c) === 'S' ? 100 : 0);
const lowest = (cards) => cards.reduce((a, b) => (cost(b) < cost(a) ? b : a));

/** Pick a card to play for `seat`. With teams off there is no partner to help. */
function botPlay({ seat, hand, trick, spadesBroken, bids, teams = true }) {
  const legal = legalPlays(hand, trick, spadesBroken);
  if (legal.length === 1) return legal[0];
  const partner = teams ? (seat + 2) % 4 : -1;

  if (trick.length === 0) {
    const aces = legal.filter((c) => rankOf(c) === 14 && suitOf(c) !== 'S');
    if (aces.length) return aces[0];
    const nonSpades = legal.filter((c) => suitOf(c) !== 'S');
    if (nonSpades.length) {
      // lead low from the longest side suit
      const counts = {};
      for (const c of nonSpades) counts[suitOf(c)] = (counts[suitOf(c)] || 0) + 1;
      const longest = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
      return lowest(nonSpades.filter((c) => suitOf(c) === longest));
    }
    return lowest(legal);
  }

  const winningSeat = trickWinner(trick);
  const winningCard = trick.find((p) => p.seat === winningSeat).card;
  const winners = legal.filter((c) => beats(c, winningCard));

  if (winningSeat === partner) {
    // Partner bid Nil and is about to take this trick: rescue them.
    if (bids[partner] === 0 && winners.length) return lowest(winners);
    const lastToPlay = trick.length === 3;
    const ledSuit = suitOf(trick[0].card);
    const partnerStrong = rankOf(winningCard) >= 13 || (suitOf(winningCard) === 'S' && ledSuit !== 'S');
    if (lastToPlay || partnerStrong) return lowest(legal);
  }

  if (winners.length) return lowest(winners);
  return lowest(legal);
}

module.exports = { botBid, botPlay };
