/* Shared helpers for the table (iPad) and player (phone) screens. */
(function () {
  'use strict';

  // ︎ asks iOS to draw the suit as text, not as a coloured emoji.
  const SUIT_SYMBOL = { S: '♠︎', H: '♥︎', D: '♦︎', C: '♣︎' };
  const SUIT_WORD = { S: 'spades', H: 'hearts', D: 'diamonds', C: 'clubs' };
  const SEAT_NAMES = ['North', 'East', 'South', 'West'];

  const rankLabel = (card) => (card[0] === 'T' ? '10' : card[0]);
  const isRed = (card) => card[1] === 'H' || card[1] === 'D';
  const cardText = (card) => rankLabel(card) + SUIT_SYMBOL[card[1]];

  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  }

  function cardEl(card, extraClass) {
    const el = document.createElement('div');
    const face = 'JQK'.includes(card[0]);
    el.className = 'card' + (isRed(card) ? ' red' : '') + (face ? ' face' : '') + (extraClass ? ' ' + extraClass : '');
    el.dataset.card = card;
    const r = rankLabel(card);
    const s = SUIT_SYMBOL[card[1]];
    el.innerHTML =
      `<span class="corner tl">${r}<i>${s}</i></span>` +
      `<span class="pip">${face ? `<b>${r}</b><i>${s}</i>` : s}</span>` +
      `<span class="corner br">${r}<i>${s}</i></span>`;
    el.setAttribute('aria-label', `${r} of ${SUIT_WORD[card[1]]}`);
    return el;
  }

  // ---------- teams or every player for themselves ----------
  const isTeams = (st) => (st.game ? st.game.settings.teams : st.settings.teams) !== false;
  const unitsOf = (st) => (st.game ? st.game.units : isTeams(st) ? [[0, 2], [1, 3]] : [[0], [1], [2], [3]]);
  const unitOf = (st, seat) => (isTeams(st) ? seat % 2 : seat);
  /** Colour class: teams share a colour; in 1v1v1v1 every seat has its own. */
  const colorOf = (st, seat) => 'c' + unitOf(st, seat);
  const nameOf = (st, seat) => (st.seats[seat] ? st.seats[seat].name : SEAT_NAMES[seat]);
  function unitName(st, unit) {
    const seats = unitsOf(st)[unit];
    if (seats.length === 1) return nameOf(st, seats[0]);
    const named = seats.map((s) => st.seats[s]);
    if (named.every(Boolean)) return named.map((s) => s.name).join(' & ');
    return seats.map((s) => SEAT_NAMES[s]).join(' & ');
  }
  const bidText = (b) => (b === null || b === undefined ? '–' : b === 0 ? 'Nil' : String(b));
  function unitBidText(bids) {
    if (bids.some((b) => b === null)) return '';
    const total = bids.filter((b) => b > 0).reduce((a, b) => a + b, 0);
    const parts = total > 0 ? [String(total)] : [];
    bids.filter((b) => b === 0).forEach(() => parts.push('Nil'));
    return parts.join(' + ');
  }
  const signed = (n) => (n > 0 ? '+' + n : String(n));

  /** What happened between two states, for sounds and animations. */
  function diffEvents(prev, st) {
    const events = [];
    const a = prev && prev.game;
    const b = st.game;
    if (!a || !b) return events;
    if (a.handNumber !== b.handNumber) {
      events.push({ type: 'deal' });
      return events;
    }
    for (let i = 0; i < 4; i++) {
      if (a.bids[i] === null && b.bids[i] !== null) events.push({ type: 'bid', seat: i, bid: b.bids[i] });
    }
    for (const p of b.trick) {
      if (!a.trick.some((q) => q.card === p.card)) events.push({ type: 'card', seat: p.seat, card: p.card });
    }
    const total = (g) => g.tricksWon.reduce((x, y) => x + y, 0);
    if (total(b) > total(a) && b.lastTrick) events.push({ type: 'collect', winner: b.lastTrick.winner, cards: b.lastTrick.cards });
    if (a.phase !== b.phase && b.phase === 'handOver') events.push({ type: 'handOver' });
    if (a.phase !== b.phase && b.phase === 'gameOver') events.push({ type: 'gameOver', winner: b.winner });
    if (b.turn !== null && b.turn !== a.turn) events.push({ type: 'turn', seat: b.turn });
    return events;
  }

  /**
   * The cards in the middle of the table. Each played card flies in from its player,
   * and a finished trick sweeps off toward the winner.
   * opts.slot(seat, card)    -> {x, y, rot}   resting place (relative to the centre point)
   * opts.origin(seat, card)  -> {x, y, rot?, scale?}  where a new card flies in from
   * opts.sweepTo(seat)       -> {x, y, scale?}  where a won trick goes
   */
  class TrickView {
    constructor(el, opts) {
      this.el = el;
      this.opts = opts;
      this.shown = new Map();
      this.cw = 80;
    }

    setCardWidth(cw) {
      this.cw = cw;
      this.el.style.setProperty('--cw', cw + 'px');
    }

    /** Convert a screen rectangle to a point relative to the trick centre. */
    local(rect) {
      const c = this.el.getBoundingClientRect();
      return { x: rect.left + rect.width / 2 - c.left, y: rect.top + rect.height / 2 - c.top };
    }

    place(el, p, scale) {
      const s = scale === undefined ? 1 : scale;
      el.style.transform = `translate(${p.x - this.cw / 2}px, ${p.y - this.cw * 0.7}px) rotate(${p.rot || 0}deg) scale(${s})`;
    }

    update(g, animate) {
      const trick = g && g.phase === 'playing' ? g.trick : [];
      const stale = [...this.shown].filter(([seat, el]) => !trick.some((p) => p.seat === seat && p.card === el.dataset.card));
      if (stale.length) {
        stale.forEach(([seat]) => this.shown.delete(seat));
        const lt = g && g.lastTrick;
        const fromLast = lt && stale.every(([, el]) => lt.cards.some((c) => c.card === el.dataset.card));
        if (animate && fromLast) this.sweep(stale.map(([, el]) => el), lt.winner);
        else stale.forEach(([, el]) => el.remove());
      }
      trick.forEach((p, i) => {
        if (this.shown.has(p.seat)) return;
        const el = cardEl(p.card);
        el.style.zIndex = String(10 + i);
        const slot = this.opts.slot(p.seat, p.card);
        el.dataset.rot = String(slot.rot || 0);
        this.el.appendChild(el);
        this.shown.set(p.seat, el);
        if (animate) {
          const from = this.opts.origin(p.seat, p.card);
          el.style.transition = 'none';
          this.place(el, { x: from.x, y: from.y, rot: from.rot === undefined ? slot.rot : from.rot }, from.scale === undefined ? 0.7 : from.scale);
          el.style.opacity = from.opacity === undefined ? '0.25' : String(from.opacity);
          void el.offsetWidth; // apply the start position before animating
          el.style.transition = '';
          requestAnimationFrame(() => {
            this.place(el, slot, 1);
            el.style.opacity = '1';
          });
        } else {
          this.place(el, slot, 1);
        }
      });
      for (const [seat, el] of this.shown) el.classList.toggle('winning', !!g && g.trickWinner === seat);
    }

    sweep(els, winner) {
      const to = this.opts.sweepTo(winner);
      els.forEach((el, i) => {
        el.classList.add('sweeping');
        el.classList.remove('winning');
        el.style.transitionDelay = i * 45 + 'ms';
        this.place(el, { x: to.x, y: to.y, rot: Number(el.dataset.rot) || 0 }, to.scale === undefined ? 0.45 : to.scale);
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 1000);
      });
    }

    relayout() {
      for (const [seat, el] of this.shown) {
        const slot = this.opts.slot(seat, el.dataset.card);
        el.dataset.rot = String(slot.rot || 0);
        el.style.transition = 'none';
        this.place(el, slot, 1);
        void el.offsetWidth;
        el.style.transition = '';
      }
    }

    clear() {
      for (const el of this.shown.values()) el.remove();
      this.shown.clear();
    }
  }

  // ---------- storage, ids, server calls ----------
  // localStorage can throw (private mode, blocked storage), so keep a memory fallback.
  const memory = {};
  const fromMemory = (k) => (Object.prototype.hasOwnProperty.call(memory, k) ? memory[k] : null);
  const store = {
    get(k) {
      try {
        const v = localStorage.getItem(k);
        return v === null ? fromMemory(k) : v;
      } catch (e) {
        return fromMemory(k);
      }
    },
    set(k, v) {
      memory[k] = v;
      try {
        localStorage.setItem(k, v);
      } catch (e) {
        /* memory only */
      }
    },
  };

  function randomId() {
    const a = new Uint8Array(16);
    crypto.getRandomValues(a); // works on plain http too, unlike crypto.randomUUID
    return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
  }

  /** This device's player id. Add ?slot=2 to the URL to test several players in one browser. */
  function getToken() {
    const slot = new URLSearchParams(location.search).get('slot');
    const key = 'spades.token' + (slot ? '.' + slot : '');
    let t = store.get(key);
    if (!t) {
      t = randomId();
      store.set(key, t);
    }
    return t;
  }

  /** Emit with an acknowledgement; always resolves to {ok, error?, ...}. */
  function call(socket, event, data) {
    return new Promise((resolve) => {
      socket.timeout(10000).emit(event, data || {}, (err, res) => {
        if (err) resolve({ ok: false, error: 'No answer from the server. Check your connection.' });
        else resolve(res || { ok: false, error: 'No answer from the server.' });
      });
    });
  }

  /** An in-page yes/no question (the browser's own confirm() is blocked in some places). */
  function ask(message, yesLabel, noLabel) {
    return new Promise((resolve) => {
      const wrap = document.createElement('div');
      wrap.className = 'ask';
      wrap.innerHTML =
        `<div class="ask-box" role="dialog" aria-modal="true"><p>${esc(message)}</p>` +
        `<div class="ask-actions"><button class="btn" data-a="0" type="button">${esc(noLabel || 'Cancel')}</button>` +
        `<button class="btn primary" data-a="1" type="button">${esc(yesLabel || 'Yes')}</button></div></div>`;
      const done = (v) => {
        wrap.remove();
        resolve(v);
      };
      wrap.addEventListener('click', (e) => {
        const b = e.target.closest('[data-a]');
        if (b) done(b.dataset.a === '1');
        else if (e.target === wrap) done(false);
      });
      document.body.appendChild(wrap);
      wrap.querySelector('[data-a="1"]').focus();
    });
  }

  let toastTimer = null;
  function toast(msg, ms) {
    let el = document.getElementById('toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'toast';
      el.className = 'toast';
      el.setAttribute('role', 'status');
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), ms || 2600);
  }

  /** Shows a bar while the connection is down. */
  function connectionBanner(socket) {
    const el = document.createElement('div');
    el.className = 'conn hidden';
    el.textContent = 'Reconnecting…';
    document.body.appendChild(el);
    let timer = null;
    socket.on('disconnect', () => {
      clearTimeout(timer);
      timer = setTimeout(() => el.classList.remove('hidden'), 800); // ignore tiny blips
    });
    socket.on('connect', () => {
      clearTimeout(timer);
      el.classList.add('hidden');
    });
  }

  /** Keep the screen on during a game, where the browser allows it. */
  function keepAwake() {
    if (!('wakeLock' in navigator)) return;
    let lock = null;
    const request = async () => {
      if (lock || document.visibilityState !== 'visible') return;
      try {
        lock = await navigator.wakeLock.request('screen');
        lock.addEventListener('release', () => {
          lock = null;
        });
      } catch (e) {
        /* not allowed yet; try again on the next tap */
      }
    };
    document.addEventListener('visibilitychange', request);
    document.addEventListener('pointerdown', request);
    request();
  }

  window.Spades = {
    SUIT_SYMBOL,
    SUIT_WORD,
    SEAT_NAMES,
    rankLabel,
    isRed,
    cardText,
    cardEl,
    esc,
    isTeams,
    unitsOf,
    unitOf,
    colorOf,
    nameOf,
    unitName,
    bidText,
    unitBidText,
    signed,
    diffEvents,
    TrickView,
    store,
    getToken,
    call,
    ask,
    toast,
    connectionBanner,
    keepAwake,
  };
})();
