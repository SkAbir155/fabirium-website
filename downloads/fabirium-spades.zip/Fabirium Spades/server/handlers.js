'use strict';

// What the server does with each message from a screen. Works with a real Socket.IO
// socket, or with anything that has `data`, `on(event, fn)` and `emit(event, payload)`
// (the in-browser preview uses that).

const { GameError } = require('./game');

/** The state update every screen gets after a change; each socket only sees its own hand. */
function broadcast(room) {
  for (const sock of room.sockets) sock.emit('state', room.view(sock.data.role, sock.data.token));
}

/**
 * @param {{data:object, on:Function}} socket
 * @param {import('./rooms').RoomManager} rooms
 */
function registerHandlers(socket, rooms) {
  socket.data = { role: null, token: null, room: null };

  const leaveRoom = () => {
    const room = socket.data.room;
    if (!room) return;
    room.sockets.delete(socket);
    socket.data.room = null;
    if (!room.checkQuit()) room.changed(); // a pending quit vote may now be complete
  };

  const enter = (room, role, token) => {
    if (socket.data.room && socket.data.room !== room) leaveRoom();
    socket.data.role = role;
    socket.data.token = token;
    socket.data.room = room;
    room.sockets.add(socket);
  };

  const currentRoom = () => {
    if (!socket.data.room) throw new GameError('Not connected to a room.');
    return socket.data.room;
  };
  const asPlayer = () => {
    const room = currentRoom();
    if (socket.data.role !== 'player') throw new GameError('Only players can do that.');
    return room;
  };
  /** The iPad table, or the host's phone in a phones-only game. */
  const asController = () => {
    const room = currentRoom();
    room.requireControl(socket.data.role, socket.data.token);
    return room;
  };
  /** The iPad table, or anyone with a seat. */
  const asParticipant = () => {
    const room = currentRoom();
    if (socket.data.role === 'player') room.requireSeat(socket.data.token);
    return room;
  };
  const checkToken = (token) => {
    if (typeof token !== 'string' || token.length < 8 || token.length > 64) {
      throw new GameError('Bad player id. Reload the page.');
    }
  };

  // Every event gets an ack: {ok:true, ...} or {ok:false, error}.
  const handle = (event, fn) =>
    socket.on(event, (payload, ack) => {
      const reply = typeof ack === 'function' ? ack : () => {};
      try {
        const result = fn(payload && typeof payload === 'object' ? payload : {});
        reply({ ok: true, ...(result && typeof result === 'object' ? result : {}) });
      } catch (err) {
        if (err instanceof GameError) reply({ ok: false, error: err.message });
        else {
          console.error(`[${event}]`, err);
          reply({ ok: false, error: 'Something went wrong on the server.' });
        }
      }
    });

  // ---- table (iPad) ----
  handle('table:create', () => {
    const room = rooms.create('table');
    enter(room, 'table', null);
    room.changed();
    return { code: room.code };
  });
  handle('table:watch', ({ code }) => {
    const room = rooms.get(code);
    if (!room) throw new GameError('That room no longer exists. Start a new table.');
    enter(room, 'table', null);
    room.changed();
    return { code: room.code };
  });

  // ---- host controls (iPad, or the host phone when there is no iPad) ----
  handle('room:settings', (patch) => asController().updateSettings(patch));
  handle('room:kick', ({ seat }) => asController().kick(seat));
  handle('room:start', () => asController().start());
  handle('room:botControl', ({ seat, on }) => asController().setBotControl(seat, on));

  // ---- anyone at the table ----
  handle('game:next', () => asParticipant().nextHand());
  handle('game:playAgain', () => asParticipant().playAgain());
  handle('game:quit', () => asParticipant().requestQuit(socket.data.role, socket.data.token));
  handle('game:quitVote', ({ agree }) => asPlayer().voteQuit(socket.data.token, agree === true));
  handle('game:quitCancel', () => asParticipant().cancelQuit());

  // ---- players (phones) ----
  handle('player:create', ({ token, name }) => {
    checkToken(token);
    const room = rooms.create('phones', token);
    enter(room, 'player', token);
    room.sit(token, name, 2); // the host starts in the South seat and can move
    return { code: room.code, seat: room.seatOf(token) };
  });
  handle('player:join', ({ code, token }) => {
    checkToken(token);
    const room = rooms.get(code);
    if (!room) throw new GameError('Room not found. Check the code.');
    enter(room, 'player', token);
    room.reclaim(token);
    if (!room.checkQuit()) room.changed();
    return { code: room.code, seat: room.seatOf(token) };
  });
  handle('player:sit', ({ seat, name }) => asPlayer().sit(socket.data.token, name, seat));
  handle('player:leave', () => asPlayer().leave(socket.data.token));
  handle('player:bid', ({ bid }) => asPlayer().bid(socket.data.token, bid));
  handle('player:play', ({ card }) => asPlayer().play(socket.data.token, card));

  socket.on('disconnect', leaveRoom);
}

module.exports = { registerHandlers, broadcast };
