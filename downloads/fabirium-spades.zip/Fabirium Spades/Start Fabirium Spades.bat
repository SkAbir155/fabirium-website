@echo off
title Fabirium Spades
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed on this PC.
  echo  Install the LTS version from https://nodejs.org and then run this file again.
  echo.
  pause
  exit /b
)
if not exist node_modules (
  echo  First start: getting the game ready. This needs internet once and takes about a minute...
  call npm install --omit=dev --no-audit --no-fund
)
echo.
echo  Starting Fabirium Spades. Keep this window open while you play.
echo  Open one of the addresses below on the iPad or a phone on the same Wi-Fi.
echo.
call npm start
pause
