# Fabirium Spades

A Spades game by Fabirium Arcade for 4 players on phones, with or without an iPad. Players can be on any network (same Wi-Fi, other Wi-Fi or mobile data) once the game is online.

## Two ways to play

- **📺 iPad in the middle:** the iPad is the table. It shows the played cards (each one turned to face the player who threw it), bids, tricks and scores. Each phone shows **only that player's cards**. A player can still tap **Show table** to see the table on their own phone.
- **📱 Phones only:** no iPad. Whoever taps **Phones only** becomes the host. Every phone shows the whole table plus its own cards.

## How to play

1. Start a game: on the iPad open the site and tap **iPad in the middle**, or on a phone tap **Phones only**. You get a QR code and a 4-letter room code.
2. Everyone else scans the QR code (or opens the site, types the code and taps **Join**), enters a name and picks a seat.
3. Choose **2 vs 2** (partners sit across from each other) or **1 v 1 v 1 v 1** (every player for themselves), pick the other rules, and tap **Start game**. With fewer than 4 people, bots fill the empty seats.
4. On your phone, bid when it's your turn. Then **tap a card, and tap it again to play it**. Cards you can't play are greyed out. The card flies off your phone onto the table, and when you win a trick, its cards fly back into your pile.
5. After each hand, tap **Next hand**. When someone reaches the target score, tap **Play again**.

### Quitting
Anyone can tap **Quit**, but the game only ends when **every player agrees** on their own phone. One "Keep playing" cancels the request, and an unanswered request expires after a minute.

### Rules used
- Spades are always trump. You must follow the led suit if you can.
- Nobody can lead spades until a spade has been played (unless that player has only spades).
- **Bid made:** 10 × bid, plus 1 point per extra trick (a "bag").
- **Bid missed:** −10 × bid.
- **Nil** (bid 0): +100 if you take no tricks, −100 if you take any. In 2 vs 2, your partner's bid counts on its own.
- **Bags:** every 10 bags costs 100 points (can be turned off).
- The first team or player to the target (250 / 300 / 500) wins. Falling to −200 ends the game, and the highest score wins.

### Music and sound
- **iPad in the middle:** the music plays **only on the iPad**. Turn it off with the iPad's **🔊 Sound** button → **Music**. Phones play only sound effects (your turn, your card, winning a trick), and their 🔊 menu shows that the music is on the iPad.
- **Phones only:** the music plays on **every phone**. Each player can turn it off on their own phone with the 🔊 button → **Music**.
- Sound effects can be turned off the same way on any screen. Each device remembers its choice.
- The music and sounds are generated in the browser, so there are no audio files. Browsers only allow sound after the first tap on the screen. On iPhone or iPad, turn off silent mode if you hear nothing.

### Table screen tips
- **Face players** (on by default) turns each name and played card toward that player's side, for an iPad lying flat in the middle. Tap it to switch off.
- **Tap a player's name** during a game to let a bot play for them, for example if their phone died. When their phone reconnects, they get the seat back automatically.
- On the iPad, use Safari's **Share → Add to Home Screen** to get a full-screen app without the address bar.
- If a phone locks or the page reloads, reopening it puts the player back in the same seat with the same cards.

## Run it on your computer

Needs [Node.js](https://nodejs.org) 18 or newer.

```bash
npm install
npm start
```

- On the computer: http://localhost:3000
- Phones and iPad on the **same Wi-Fi**: use the `http://192.168.x.x:3000` address printed in the terminal. Open the table from that address too, so the QR code points somewhere the phones can reach.
- To test several players in one browser, add `&slot=2`, `&slot=3`, … to the phone URL. Each slot is a separate player.

## Put it online (free) so friends on mobile data can join

These steps use [Render](https://render.com)'s free plan.

1. Put this folder on GitHub (a free account works):
   ```bash
   git init
   git add .
   git commit -m "Fabirium Spades"
   git branch -M main
   git remote add origin https://github.com/<your-username>/fabirium-spades.git
   git push -u origin main
   ```
   Create the empty `fabirium-spades` repository on github.com first.
2. On render.com: **New → Web Service**, then connect your GitHub account and pick the repository.
3. Use these settings:
   - **Runtime:** Node
   - **Build command:** `npm install`
   - **Start command:** `npm start`
   - **Instance type:** Free
4. Click **Create Web Service**. After a few minutes you get a link like `https://fabirium-spades-xxxx.onrender.com`. Open it on the iPad and tap **Create table**.

On the free plan the server sleeps after 15 minutes with no players. The first visit after that takes about a minute to wake it up. Games live in the server's memory, so a game in progress is lost if the server restarts.

## Tests

```bash
npm test           # rules and scoring
npm run simulate   # complete games over real connections: privacy, reconnecting, bots, phones-only, quit votes
```

## Project layout

| Path | What it does |
|---|---|
| `server/game.js` | Spades rules: dealing, legal plays, trick winner, scoring |
| `server/bot.js` | Computer player for empty seats |
| `server/rooms.js` | Rooms, seats, host, quit votes, reconnecting, timers. Each phone only ever receives its own hand. |
| `server/handlers.js` | What the server does with each message from a screen |
| `server/index.js` | Web server, Socket.IO events, QR code |
| `public/table.*` | iPad table screen (`/table`) |
| `public/player.*` | Phone hand screen (`/play`) |
| `public/common.*` | Card drawing, card animations and shared helpers |
| `public/sound.js` | Background music and sound effects (Web Audio, no files) |
