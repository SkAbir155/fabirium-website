/* iPad table screen: shows the shared table, never any player's hand. */
(function () {
  'use strict';

  const S = window.Spades;
  const $ = (id) => document.getElementById(id);
  const socket = io();
  S.connectionBanner(socket);
  S.keepAwake();
  // In an iPad game the iPad is the only screen that plays music (on by default).
  Sound.setup({ music: true, scope: 'table' });
  Sound.mountButton($('tools'), { label: true, align: 'left' });

  const felt = $('felt');
  const seatEls = [0, 1, 2, 3].map((i) => $('seat' + i));
  const OUTWARD = [
    [0, -1],
    [1, 0],
    [0, 1],
    [-1, 0],
  ]; // direction from the table centre toward each seat (N, E, S, W)

  let code = (new URLSearchParams(location.search).get('room') || '').trim().toUpperCase();
  let state = null;
  let facing = S.store.get('spades.facing') !== '0'; // on by default: cards face whoever played them
  let lobbyCode = null;
  let overlayKey = null;
  let lastTrickKey = null;
  let voteKey = null;

  document.body.classList.toggle('facing', facing);

  // ---------- the trick ----------
  function seatPoint(seat) {
    return trick.local(seatEls[seat].getBoundingClientRect());
  }

  const trick = new S.TrickView($('trick'), {
    slot(seat, card) {
      const cw = trick.cw;
      const h = cw * 1.4;
      const side = facing ? 1.45 * cw : 1.15 * cw;
      const xy = [
        [0, -0.62 * h],
        [side, 0],
        [0, 0.62 * h],
        [-side, 0],
      ][seat];
      let rot;
      if (facing) rot = [180, -90, 0, 90][seat];
      else {
        let n = 0;
        for (const ch of card) n += ch.charCodeAt(0);
        rot = ((n % 9) - 4) * 1.6; // a little natural tilt
      }
      return { x: xy[0], y: xy[1], rot };
    },
    // Cards slide in from beyond the player's edge of the table.
    origin(seat) {
      const p = seatPoint(seat);
      const d = OUTWARD[seat];
      return { x: p.x + d[0] * 140, y: p.y + d[1] * 140, scale: 0.85, opacity: 0.4 };
    },
    // A won trick flies off the table toward the winner.
    sweepTo(seat) {
      const p = seatPoint(seat);
      const d = OUTWARD[seat];
      return { x: p.x + d[0] * 320, y: p.y + d[1] * 320, scale: 0.7 };
    },
  });

  function sizeTable() {
    const r = felt.getBoundingClientRect();
    const portrait = r.height > r.width;
    trick.setCardWidth(Math.round(Math.max(56, Math.min(132, Math.min(r.width, r.height) * (portrait ? 0.13 : 0.15)))));
  }

  // ---------- connection ----------
  socket.on('connect', async () => {
    const res = code ? await S.call(socket, 'table:watch', { code }) : await S.call(socket, 'table:create');
    if (!res.ok) return showGone(res.error);
    if (code !== res.code) {
      code = res.code;
      history.replaceState(null, '', '/table?room=' + code);
    }
  });

  socket.on('state', (st) => {
    const prev = state;
    state = st;
    render(prev, st);
  });

  function showGone(message) {
    document.body.dataset.phase = 'gone';
    $('overlay').classList.remove('hidden');
    $('overlayPanel').className = 'panel';
    $('overlayPanel').innerHTML =
      `<h2>Table not found</h2><p class="sub">${S.esc(message || '')}</p>` +
      `<div class="actions"><button class="btn primary big" id="newTable" type="button">Start a new table</button></div>`;
    $('newTable').onclick = () => (location.href = '/table');
  }

  async function send(event, data) {
    const res = await S.call(socket, event, data);
    if (!res.ok) S.toast(res.error);
    return res;
  }

  const initial = (name) => (Array.from(name.trim())[0] || '?').toUpperCase();
  const nameOf = (seat) => S.nameOf(state, seat);

  // ---------- render ----------
  function render(prev, st) {
    document.body.dataset.phase = st.phase;
    $('roomChip').textContent = 'Room ' + st.code;
    $('quitBtn').classList.toggle('hidden', st.phase === 'lobby');
    renderTopbar(st);
    if (st.phase === 'lobby') renderLobby(st);
    renderSeats(st);
    const animate = !!prev && !document.hidden;
    trick.update(st.game, animate);
    renderNote(st);
    renderLastTrick(st);
    renderVote(st);
    renderOverlay(st);
    playEvents(prev, st);
  }

  function playEvents(prev, st) {
    for (const ev of S.diffEvents(prev, st)) {
      if (ev.type === 'card') Sound.play('card');
      else if (ev.type === 'collect') {
        Sound.play('sweep');
        bumpWon(ev.winner);
      } else if (ev.type === 'deal') Sound.play('deal');
      else if (ev.type === 'bid') Sound.play('bid');
      else if (ev.type === 'handOver') Sound.play('handOver');
      else if (ev.type === 'gameOver') Sound.play('gameOver');
    }
    if (prev && !prev.game && st.game) Sound.play('deal');
  }

  function bumpWon(seat) {
    const el = seatEls[seat].querySelector('.won');
    if (!el) return;
    el.classList.remove('bump');
    void el.offsetWidth;
    el.classList.add('bump');
  }

  function renderTopbar(st) {
    const g = st.game;
    const units = S.unitsOf(st);
    const solo = units.length === 4;
    const box = (u) => {
      let sub;
      if (g) {
        const parts = [];
        const bid = S.unitBidText(units[u].map((s) => g.bids[s]));
        if (bid && (g.phase === 'playing' || g.phase === 'bidding')) parts.push(`Bid ${bid}`);
        if (g.phase === 'playing') parts.push(`Took ${units[u].reduce((a, s) => a + g.tricksWon[s], 0)}`);
        parts.push(`Bags ${g.bags[u]}`);
        sub = parts.join(' · ');
      } else {
        sub = units[u].map((s) => S.SEAT_NAMES[s]).join(' & ');
      }
      return (
        `<div class="unit c${u}"><span class="bar"></span>` +
        `<div class="uinfo"><div class="uname">${S.esc(S.unitName(st, u))}</div><div class="usub">${sub}</div></div>` +
        `<div class="uscore">${g ? g.scores[u] : 0}</div></div>`
      );
    };
    const half = units.length / 2;
    const left = [];
    const right = [];
    units.forEach((_, u) => (u < half ? left : right).push(box(u)));
    $('unitsLeft').className = 'units' + (solo ? ' solo' : '');
    $('unitsRight').className = 'units right' + (solo ? ' solo' : '');
    $('unitsLeft').innerHTML = left.join('');
    $('unitsRight').innerHTML = right.join('');

    $('handInfo').textContent = g ? `Hand ${g.handNumber} · playing to ${g.settings.target}` : 'Waiting for players';
    $('broken').classList.toggle('on', !!(g && g.spadesBroken));
    let status = '';
    if (g) {
      if (g.phase === 'bidding') status = `${nameOf(g.turn)} is bidding…`;
      else if (g.phase === 'playing') {
        if (g.trickWinner !== null) status = `${nameOf(g.trickWinner)} wins the trick`;
        else if (g.trick.length === 0) status = `${nameOf(g.turn)} leads`;
        else status = `${nameOf(g.turn)}'s turn`;
      } else if (g.phase === 'handOver') status = 'Hand over';
      else if (g.phase === 'gameOver') status = 'Game over';
    }
    $('status').textContent = status;
  }

  function renderSeats(st) {
    const g = st.game;
    st.seats.forEach((s, i) => {
      const active = g && (g.phase === 'bidding' || g.phase === 'playing') && g.turn === i;
      let tag = '';
      if (s && s.isBot) tag = 'Bot';
      else if (s && s.botControl) tag = 'Bot playing';
      else if (s && !s.connected) tag = 'Offline';
      let bid = '–';
      if (g && g.bids[i] !== null) bid = S.bidText(g.bids[i]);
      else if (active && g.phase === 'bidding') bid = '…';
      const cls = ['plate', S.colorOf(st, i)];
      if (active) cls.push('turn');
      if (s && !s.isBot && !s.connected && !s.botControl) cls.push('offline');
      seatEls[i].innerHTML =
        `<div class="${cls.join(' ')}">` +
        `<div class="avatar">${s ? S.esc(initial(s.name)) : '?'}</div>` +
        `<div class="pinfo"><div class="pname">${s ? S.esc(s.name) : 'Empty'}` +
        `${g && g.dealer === i ? '<span class="dealer" title="Dealer">D</span>' : ''}</div>` +
        `<div class="pstats">` +
        (g ? `<span>Bid <b>${bid}</b></span><span class="won">Won <b>${g.tricksWon[i]}</b></span>` : `<span>${S.SEAT_NAMES[i]}</span>`) +
        `</div></div>` +
        (tag ? `<div class="ptag">${tag}</div>` : '') +
        `</div>`;
    });
  }

  function renderNote(st) {
    const g = st.game;
    let html = '';
    if (g && g.phase === 'bidding') html = `Bidding<small>${S.esc(nameOf(g.turn))} is choosing…</small>`;
    else if (g && g.phase === 'playing' && g.trick.length === 0 && g.trickWinner === null && trick.shown.size === 0) {
      html = `<small>${S.esc(nameOf(g.turn))} leads</small>`;
    }
    $('centerNote').innerHTML = html;
  }

  function renderLastTrick(st) {
    const g = st.game;
    const box = $('lastTrick');
    const lt = g && g.phase === 'playing' ? g.lastTrick : null;
    const key = lt ? JSON.stringify(lt) : '';
    if (key === lastTrickKey) return;
    lastTrickKey = key;
    box.classList.toggle('hidden', !lt);
    if (!lt) return;
    box.querySelector('.lt-title').textContent = `Last trick · ${nameOf(lt.winner)}`;
    const cards = box.querySelector('.lt-cards');
    cards.innerHTML = '';
    for (const p of lt.cards) cards.appendChild(S.cardEl(p.card, 'mini' + (p.seat === lt.winner ? ' won' : '')));
  }

  // ---------- quit vote ----------
  function renderVote(st) {
    const v = st.quitVote;
    const el = $('voteBanner');
    const key = v ? JSON.stringify(v) : '';
    if (key === voteKey) return;
    if (v && !voteKey) Sound.play('alert');
    voteKey = key;
    el.classList.toggle('hidden', !v);
    if (!v) return;
    const by = v.by >= 0 ? nameOf(v.by) : 'The table';
    el.innerHTML =
      `<b>${S.esc(by)} wants to quit the game.</b><div class="hint" style="margin:4px 0 0">Everyone has to agree on their phone.</div>` +
      `<ul class="vote">${v.voters
        .map((s) => {
          const yes = v.agreed.includes(s);
          return `<li class="${yes ? 'yes' : ''}">${yes ? '✓ ' : '… '}${S.esc(nameOf(s))}</li>`;
        })
        .join('')}</ul>` +
      `<button class="btn ghost" id="voteCancel" type="button">Keep playing</button>`;
    $('voteCancel').onclick = () => send('game:quitCancel');
  }

  $('quitBtn').addEventListener('click', () => {
    if (state && state.quitVote) return;
    S.ask('Ask every player to quit this game? It only ends if everyone agrees.', 'Ask to quit').then((ok) => ok && send('game:quit'));
  });

  // ---------- lobby ----------
  function renderLobby(st) {
    if (lobbyCode !== st.code) {
      lobbyCode = st.code;
      const joinUrl = `${location.origin}/play?room=${st.code}`;
      $('qr').src = '/qr.svg?data=' + encodeURIComponent(joinUrl);
      $('joinHost').textContent = location.host + '/play';
      $('bigCode').textContent = st.code;
    }
    const teams = st.settings.teams;
    document.querySelectorAll('.lseat').forEach((btn) => {
      const i = Number(btn.dataset.seat);
      const s = st.seats[i];
      btn.className = 'lseat ' + S.colorOf(st, i) + (s ? ' filled' : '') + (s && !s.connected ? ' away' : '');
      btn.innerHTML = `<small>${S.SEAT_NAMES[i]}</small><b>${s ? S.esc(s.name) : 'Empty'}</b>`;
    });
    $('seatHint').textContent = (teams ? 'Partners sit across from each other.' : 'Every player for themselves.') + ' Tap a player to remove them.';
    const set = st.settings;
    document.querySelectorAll('#teamsSeg button').forEach((b) => b.classList.toggle('on', (b.dataset.teams === '1') === set.teams));
    document.querySelectorAll('#targetSeg button').forEach((b) => b.classList.toggle('on', Number(b.dataset.target) === set.target));
    $('setNil').checked = set.nil;
    $('setBags').checked = set.bagPenalty;
    $('setBots').checked = set.fillBots;

    const humans = st.seats.filter(Boolean).length;
    const empty = 4 - humans;
    $('startBtn').disabled = !(set.fillBots || empty === 0);
    let hint;
    if (humans === 0) hint = set.fillBots ? 'Nobody has joined yet. Starting now gives you 4 bots to watch.' : 'Waiting for 4 players to join.';
    else if (empty === 0) hint = 'All 4 seats are filled. Ready!';
    else if (set.fillBots) hint = `${humans} player${humans > 1 ? 's' : ''} seated. ${empty} bot${empty > 1 ? 's' : ''} will fill the empty seat${empty > 1 ? 's' : ''}.`;
    else hint = `${humans} of 4 seated. Turn on bots or wait for more players.`;
    $('startHint').textContent = hint;
  }

  document.querySelectorAll('#teamsSeg button').forEach((b) =>
    b.addEventListener('click', () => send('room:settings', { teams: b.dataset.teams === '1' })),
  );
  document.querySelectorAll('#targetSeg button').forEach((b) =>
    b.addEventListener('click', () => send('room:settings', { target: Number(b.dataset.target) })),
  );
  $('setNil').addEventListener('change', (e) => send('room:settings', { nil: e.target.checked }));
  $('setBags').addEventListener('change', (e) => send('room:settings', { bagPenalty: e.target.checked }));
  $('setBots').addEventListener('change', (e) => send('room:settings', { fillBots: e.target.checked }));
  $('startBtn').addEventListener('click', () => send('room:start'));

  document.querySelectorAll('.lseat').forEach((btn) =>
    btn.addEventListener('click', () => {
      const i = Number(btn.dataset.seat);
      const s = state && state.seats[i];
      if (s) S.ask(`Remove ${s.name} from ${S.SEAT_NAMES[i]}?`, 'Remove').then((ok) => ok && send('room:kick', { seat: i }));
    }),
  );

  // In a game, tap a player to let a bot cover for them (or give the seat back).
  seatEls.forEach((el, i) =>
    el.addEventListener('click', () => {
      if (!state || !state.game) return;
      const s = state.seats[i];
      if (!s || s.isBot) return;
      const msg = s.botControl ? `Give the seat back to ${s.name}?` : `Let a bot play for ${s.name} until they come back?`;
      S.ask(msg).then((ok) => ok && send('room:botControl', { seat: i, on: !s.botControl }));
    }),
  );

  $('facingBtn').addEventListener('click', () => {
    facing = !facing;
    S.store.set('spades.facing', facing ? '1' : '0');
    document.body.classList.toggle('facing', facing);
    trick.relayout();
  });

  // ---------- hand summary & game over ----------
  function renderOverlay(st) {
    const g = st.game;
    const show = g && (g.phase === 'handOver' || g.phase === 'gameOver');
    const key = show ? `${g.phase}:${g.handNumber}` : '';
    if (key === overlayKey) return;
    overlayKey = key;
    $('overlay').classList.toggle('hidden', !show);
    if (!show) return;

    const r = g.lastHandResult;
    const over = g.phase === 'gameOver';
    const solo = g.units.length === 4;
    const panel = $('overlayPanel');
    panel.className = 'panel' + (over ? ' win' : '');

    const rows = r.units
      .map(
        (u) =>
          `<tr class="c${u.unit}">` +
          `<td class="tn">${S.esc(S.unitName(st, u.unit))}</td>` +
          `<td>${S.unitBidText(u.seats.map((s) => r.bids[s]))}</td>` +
          `<td>${u.tricks}</td>` +
          `<td class="${u.points >= 0 ? 'pos' : 'neg'}">${S.signed(u.points)}</td>` +
          `<td>${u.bags}${u.newBags ? ` <span class="pos">(+${u.newBags})</span>` : ''}</td>` +
          `<td class="score">${u.score}</td></tr>`,
      )
      .join('');

    const notes = [];
    for (const u of r.units) {
      const who = S.unitName(st, u.unit);
      if (u.made === true) notes.push(`✅ ${who} made their bid of ${u.bid}.`);
      if (u.made === false) notes.push(`❌ ${who} ${solo ? 'was' : 'were'} set: bid ${u.bid}, took ${u.contractTricks}.`);
      for (const n of u.nils) notes.push(n.made ? `🎯 ${nameOf(n.seat)}'s Nil worked: +100` : `💥 ${nameOf(n.seat)}'s Nil failed: −100`);
      if (u.bagPenalty) notes.push(`🎒 ${who} hit 10 bags: −${u.bagPenalty}`);
    }

    const historyRows = g.history
      .map((h) => `<tr><td>Hand ${h.handNumber}</td>${h.scores.map((sc, u) => `<td>${sc} <small>(${S.signed(h.points[u])})</small></td>`).join('')}</tr>`)
      .join('');
    const historyHead = g.units.map((_, u) => `<th>${S.esc(S.unitName(st, u))}</th>`).join('');

    const winnerName = over ? S.unitName(st, g.winner) : '';
    const title = over ? `🏆 ${S.esc(winnerName)} ${solo ? 'wins' : 'win'}!` : `Hand ${r.handNumber} results`;
    const sub = over ? `Final score ${g.scores.join(' : ')} after ${g.handNumber} hands` : `Playing to ${g.settings.target}`;

    panel.innerHTML =
      `<h2>${title}</h2><p class="sub">${sub}</p>` +
      `<table class="sumtable"><thead><tr><th>${solo ? 'Player' : 'Team'}</th><th>Bid</th><th>Took</th><th>Hand</th><th>Bags</th><th>Score</th></tr></thead><tbody>${rows}</tbody></table>` +
      `<ul class="notes">${notes.map((n) => `<li>${S.esc(n)}</li>`).join('')}</ul>` +
      (g.history.length > 1
        ? `<details class="history"${over ? ' open' : ''}><summary>Score history</summary><table class="sumtable"><thead><tr><th></th>${historyHead}</tr></thead><tbody>${historyRows}</tbody></table></details>`
        : '') +
      `<div class="actions">` +
      (over
        ? `<button class="btn primary big" id="againBtn" type="button">Play again</button>`
        : `<button class="btn primary big" id="nextBtn" type="button">Next hand</button>`) +
      `</div>`;

    if (over) $('againBtn').onclick = () => send('game:playAgain');
    else $('nextBtn').onclick = () => send('game:next');
  }

  // ---------- sizing ----------
  sizeTable();
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      sizeTable();
      trick.relayout();
    }, 80);
  });
})();
