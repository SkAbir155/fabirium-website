/* Phone screen: your own hand. With an iPad table it shows only your cards; in a
 * phones-only game (or with "Show table") it shows the whole table too. */
(function () {
  'use strict';

  const S = window.Spades;
  const $ = (id) => document.getElementById(id);
  const socket = io();
  S.connectionBanner(socket);
  S.keepAwake();
  // Music: phones-only game -> every phone plays it (on by default, each player can turn it off).
  // iPad game -> only the iPad plays it, so phones keep just the sound effects.
  // Until we know which kind of game this is, stay quiet.
  Sound.setup({ music: true, scope: 'phone' });
  Sound.allowMusic(false);
  Sound.mountButton($('toolbar'));
  Sound.mountButton(document.querySelector('#lobbyScreen .topline'));

  const params = new URLSearchParams(location.search);
  const slot = params.get('slot'); // lets one browser test several players: ?slot=2
  const token = S.getToken();
  let creating = params.has('new');
  let code = (params.get('room') || '').trim().toUpperCase();
  let name = S.store.get('spades.name') || '';
  let wantJoin = !!(code && name) && !creating;
  let state = null;
  let selected = null; // card raised in the hand
  let bidChoice = null;
  let busy = false;
  let wasMyTurn = false;
  let sheetKey = null;
  let voteKey = null;
  let actionHtml = '';
  let lobbyQr = null;
  let showTable = S.store.get('spades.phoneTable') === '1';
  let wasFull = false;
  let lastPlayed = null; // where my last played card was, so it can fly from the hand to the table
  let holdWonUntil = 0;
  let heldWon = 0;
  const handEl = $('hand');
  const handEls = new Map(); // card -> element
  let handOrder = [];

  const joinUrl = (c) => `${location.origin}/play?room=${c}`;

  // ---------- screens ----------
  function show(which) {
    $('joinScreen').classList.toggle('hidden', which !== 'join');
    $('lobbyScreen').classList.toggle('hidden', which !== 'lobby');
    $('gameScreen').classList.toggle('hidden', which !== 'game');
    $('watchScreen').classList.toggle('hidden', which !== 'watch');
    document.body.classList.toggle('in-game', which === 'game');
    if (which !== 'game') {
      sheetKey = null;
      $('sheet').classList.add('hidden');
    }
  }

  function joinError(msg) {
    $('joinErr').textContent = msg || '';
  }

  function setupJoinForm() {
    $('joinTitle').textContent = creating ? 'New game on phones' : 'Join the table';
    $('joinSub').textContent = creating ? "No iPad needed: everyone sees the whole table on their own phone. You'll be the host." : '';
    $('codeField').classList.toggle('hidden', creating);
    $('joinBtn').textContent = creating ? 'Create game' : 'Join';
  }

  // ---------- joining ----------
  $('codeInput').value = code || S.store.get('spades.room') || '';
  $('nameInput').value = name;
  setupJoinForm();
  if (!wantJoin) {
    show('join');
    (creating || $('codeInput').value ? $('nameInput') : $('codeInput')).focus();
  }

  $('joinForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const n = $('nameInput').value.trim().slice(0, 16);
    if (!n) return joinError('Enter your name.');
    name = n;
    S.store.set('spades.name', name);
    joinError('');
    if (creating) {
      wantJoin = true; // the first state arrives before the reply
      const res = await S.call(socket, 'player:create', { token, name });
      if (!res.ok) {
        wantJoin = false;
        return joinError(res.error);
      }
      creating = false;
      afterJoin(res.code);
      return;
    }
    const c = $('codeInput').value.trim().toUpperCase();
    if (!/^[A-Z]{4}$/.test(c)) return joinError('Enter the 4-letter room code.');
    code = c;
    wantJoin = true;
    if (socket.connected) join();
  });

  socket.on('connect', () => {
    if (wantJoin && code) join();
  });

  async function join() {
    const res = await S.call(socket, 'player:join', { code, token });
    if (!res.ok) {
      wantJoin = false;
      state = null;
      show('join');
      setupJoinForm();
      joinError(res.error);
      return;
    }
    afterJoin(res.code);
  }

  function afterJoin(c) {
    code = c;
    S.store.set('spades.room', code);
    const q = new URLSearchParams({ room: code });
    if (slot) q.set('slot', slot);
    history.replaceState(null, '', '/play?' + q.toString());
  }

  socket.on('state', (st) => {
    if (!wantJoin) return;
    const prev = state;
    state = st;
    render(prev, st);
  });

  async function send(event, data) {
    const res = await S.call(socket, event, data);
    if (!res.ok) S.toast(res.error);
    return res;
  }

  // ---------- render ----------
  function render(prev, st) {
    Sound.allowMusic(st.mode === 'phones');
    renderVote(st);
    if (st.phase === 'lobby') {
      show('lobby');
      renderLobby(st);
      return;
    }
    if (st.you.seat < 0) {
      show('watch');
      $('watchCode').textContent = st.code;
      return;
    }
    show('game');
    renderGame(prev, st);
  }

  // ---------- lobby ----------
  function renderLobby(st) {
    const me = st.you.seat;
    const host = st.you.isHost;
    const phones = st.mode === 'phones';
    $('lobbyCode').textContent = st.code;
    $('shareBox').classList.toggle('hidden', !phones);
    if (phones && lobbyQr !== st.code) {
      lobbyQr = st.code;
      $('shareQr').src = '/qr.svg?data=' + encodeURIComponent(joinUrl(st.code));
      $('shareCode').textContent = st.code;
    }
    document.querySelectorAll('.pseat').forEach((btn) => {
      const i = Number(btn.dataset.seat);
      const s = st.seats[i];
      const mine = i === me;
      btn.className = 'pseat ' + S.colorOf(st, i) + (mine ? ' mine' : '') + (s && !mine ? ' taken' : '');
      btn.disabled = !!s && !mine;
      btn.innerHTML = `<small>${S.SEAT_NAMES[i]}</small><b>${mine ? 'You' : s ? S.esc(s.name) : 'Open'}</b>`;
    });
    $('lobbyTitle').textContent = me >= 0 ? `You're sitting ${S.SEAT_NAMES[me]}` : 'Pick your seat';
    $('lobbyHint').textContent = st.settings.teams ? 'Partners sit across from each other.' : 'Every player for themselves (1 v 1 v 1 v 1).';

    $('hostRules').classList.toggle('hidden', !host);
    if (host) {
      const set = st.settings;
      document.querySelectorAll('#teamsSeg button').forEach((b) => b.classList.toggle('on', (b.dataset.teams === '1') === set.teams));
      document.querySelectorAll('#targetSeg button').forEach((b) => b.classList.toggle('on', Number(b.dataset.target) === set.target));
      $('setNil').checked = set.nil;
      $('setBags').checked = set.bagPenalty;
      $('setBots').checked = set.fillBots;
      const humans = st.seats.filter(Boolean).length;
      $('startBtn').disabled = !(set.fillBots || humans === 4);
      $('startHint').textContent =
        humans === 4 ? 'All 4 seats are filled.' : set.fillBots ? `${4 - humans} bot${4 - humans > 1 ? 's' : ''} will fill the empty seats.` : 'Waiting for 4 players.';
    }

    let wait = '';
    if (me < 0) wait = `Hi ${name}! Tap an open seat.`;
    else if (!host) {
      const set = st.settings;
      const partner = set.teams ? st.seats[(me + 2) % 4] : null;
      const rules = `${set.teams ? '2 vs 2' : '1 v 1 v 1 v 1'} · to ${set.target}`;
      const who = phones ? 'the host' : st.tableConnected ? 'the table' : 'the table screen';
      wait = (partner ? `Your partner is ${partner.name}. ` : '') + `${rules}. Waiting for ${who} to start…`;
    }
    $('lobbyWait').textContent = wait;
    $('leaveSeatBtn').classList.toggle('hidden', me < 0);
  }

  document.querySelectorAll('.pseat').forEach((btn) =>
    btn.addEventListener('click', () => {
      const seat = Number(btn.dataset.seat);
      if (state && state.you.seat === seat) return;
      send('player:sit', { seat, name });
    }),
  );
  $('leaveSeatBtn').addEventListener('click', () => send('player:leave'));
  $('renameBtn').addEventListener('click', () => {
    const n = (prompt('Your name', name) || '').trim().slice(0, 16);
    if (!n || n === name) return;
    name = n;
    S.store.set('spades.name', name);
    if (state && state.phase === 'lobby' && state.you.seat >= 0) send('player:sit', { seat: state.you.seat, name });
    else if (state) renderLobby(state);
  });
  $('otherRoomBtn').addEventListener('click', () => {
    wantJoin = false;
    state = null;
    creating = false;
    setupJoinForm();
    $('codeInput').value = '';
    show('join');
  });
  $('shareBtn').addEventListener('click', async () => {
    const url = joinUrl(code);
    try {
      if (navigator.share) return await navigator.share({ title: 'Fabirium Spades', text: 'Join my Fabirium Spades game', url });
      await navigator.clipboard.writeText(url);
      S.toast('Invite link copied');
    } catch (e) {
      if (e && e.name !== 'AbortError') prompt('Copy this link', url);
    }
  });
  document.querySelectorAll('#teamsSeg button').forEach((b) =>
    b.addEventListener('click', () => send('room:settings', { teams: b.dataset.teams === '1' })),
  );
  document.querySelectorAll('#targetSeg button').forEach((b) =>
    b.addEventListener('click', () => send('room:settings', { target: Number(b.dataset.target) })),
  );
  $('setNil').addEventListener('change', (e) => send('room:settings', { nil: e.target.checked }));
  $('setBags').addEventListener('change', (e) => send('room:settings', { bagPenalty: e.target.checked }));
  $('setBots').addEventListener('change', (e) => send('room:settings', { fillBots: e.target.checked }));
  $('startBtn').addEventListener('click', () => send('room:start'));

  // ---------- game ----------
  const meName = (st, seat) => (seat === st.you.seat ? 'You' : S.nameOf(st, seat));
  const isFull = (st) => st.mode === 'phones' || showTable;
  const relOf = (seat) => (seat - state.you.seat + 4) % 4;
  const whoEl = (rel) => document.querySelector(`.who[data-rel="${rel}"]`);

  function myTurn(st) {
    const g = st.game;
    const me = st.you.seat;
    return (g.phase === 'bidding' || g.phase === 'playing') && g.turn === me && !st.seats[me].botControl;
  }
  const canPlay = (st) => st.game.phase === 'playing' && myTurn(st) && st.game.trickWinner === null;

  function renderGame(prev, st) {
    const g = st.game;
    const me = st.you.seat;
    const full = isFull(st);
    const events = S.diffEvents(prev, st);
    if (!full && events.some((ev) => ev.type === 'collect' && ev.winner === me)) {
      // keep showing the old count until the flying cards land in the pile
      holdWonUntil = Date.now() + 940;
      heldWon = prev.game.tricksWon[me];
    }

    document.body.classList.toggle('full', full);
    $('viewBtn').classList.toggle('hidden', st.mode === 'phones');
    $('viewBtn').textContent = showTable ? 'Hide table' : 'Show table';
    $('handNo').textContent = `Hand ${g.handNumber} · to ${g.settings.target}`;
    $('handNo').title = `Playing to ${g.settings.target}`;
    $('brokenPill').classList.toggle('on', g.spadesBroken);
    renderScores(st);
    renderMine(st);
    renderAction(st);
    renderHand(st); // before the table: a played card's position is needed for its flight
    if (full) {
      sizeBoard();
      renderWho(st);
      boardTrick.update(g, wasFull && !!prev && !document.hidden);
    } else {
      boardTrick.clear();
    }
    wasFull = full;
    renderSheet(st);
    playEvents(st, events, full);

    const mine = myTurn(st);
    if (mine && !wasMyTurn) {
      Sound.play('turn');
      try {
        if (navigator.vibrate) navigator.vibrate([90, 60, 90]);
      } catch (e) {
        /* ignore */
      }
    }
    wasMyTurn = mine;
  }

  function playEvents(st, events, full) {
    const me = st.you.seat;
    for (const ev of events) {
      if (ev.type === 'deal') Sound.play('deal');
      else if (ev.type === 'card') {
        if (full || ev.seat === me) Sound.play('card');
      } else if (ev.type === 'collect') {
        if (ev.winner === me) {
          Sound.play('win');
          if (full) bumpWho(0);
          else flyInWon(ev.cards);
        } else if (full) {
          Sound.play('sweep');
          bumpWho(relOf(ev.winner));
        }
      } else if (ev.type === 'bid' && full) Sound.play('bid');
      else if (ev.type === 'handOver' && full) Sound.play('handOver');
      else if (ev.type === 'gameOver') Sound.play('gameOver');
    }
  }

  function renderScores(st) {
    const g = st.game;
    const myUnit = S.unitOf(st, st.you.seat);
    const solo = g.units.length === 4;
    const order = [myUnit].concat(g.units.map((_, u) => u).filter((u) => u !== myUnit));
    $('pbar').className = 'pbar' + (solo ? ' solo' : '');
    $('pbar').innerHTML = order
      .map((u) => {
        const label = u === myUnit ? (solo ? 'You' : 'Us') : solo ? S.unitName(st, u) : 'Them';
        return `<div class="pscore c${u}"><span class="pl">${S.esc(label)}</span><b>${g.scores[u]}</b><small>${g.bags[u]} bags</small></div>`;
      })
      .join('');
  }

  function renderMine(st) {
    const g = st.game;
    const me = st.you.seat;
    $('mine').className = 'mine ' + S.colorOf(st, me);
    const won = Date.now() < holdWonUntil ? heldWon : g.tricksWon[me];
    $('wonCount').textContent = won;
    const bid = g.bids[me];
    $('mineBig').textContent = bid === null ? (g.phase === 'bidding' ? 'Bidding…' : '') : `You bid ${S.bidText(bid)} · won ${won}`;
    let small = '';
    if (g.settings.teams) {
      const p = (me + 2) % 4;
      small = `Partner ${S.nameOf(st, p)}: bid ${S.bidText(g.bids[p])}, won ${g.tricksWon[p]}`;
    } else {
      small = 'Every player for themselves';
    }
    $('mineSmall').textContent = small;
  }

  function renderAction(st) {
    const g = st.game;
    const me = st.you.seat;
    let html;
    if (st.seats[me].botControl) {
      html =
        `<div class="banner">A bot is playing for you<small>Tap below when you're back.</small>` +
        `<button class="btn primary" id="reclaimBtn" type="button">Take my seat back</button></div>`;
    } else if (g.phase === 'bidding' && g.turn === me) {
      const partnerBid = g.settings.teams ? g.bids[(me + 2) % 4] : null;
      let buttons = g.settings.nil ? `<button type="button" class="nil${bidChoice === 0 ? ' on' : ''}" data-bid="0">Nil</button>` : '';
      for (let n = 1; n <= 13; n++) buttons += `<button type="button" class="${bidChoice === n ? 'on' : ''}" data-bid="${n}">${n}</button>`;
      const label = bidChoice === null ? 'Choose a number' : bidChoice === 0 ? 'Bid Nil' : `Bid ${bidChoice}`;
      html =
        `<div class="bidbox"><h3>How many tricks will you take?` +
        `${partnerBid !== null ? ` <small>(partner bid ${S.bidText(partnerBid)})</small>` : ''}</h3>` +
        `<div class="bidgrid">${buttons}</div>` +
        `<button class="btn primary" id="bidConfirm" type="button"${bidChoice === null ? ' disabled' : ''}>${label}</button></div>`;
    } else if (g.phase === 'bidding') {
      html = `<div class="banner">${S.esc(meName(st, g.turn))} is bidding…</div>`;
    } else if (g.phase === 'playing') {
      if (g.trickWinner !== null) {
        html = `<div class="banner">${g.trickWinner === me ? 'You win the trick!' : S.esc(S.nameOf(st, g.trickWinner)) + ' wins the trick'}</div>`;
      } else if (g.turn === me) {
        const tip =
          g.trick.length === 0
            ? 'You lead. Tap a card, then tap it again to play.'
            : `Follow ${S.SUIT_WORD[g.trick[0].card[1]]} if you can. Tap a card twice to play.`;
        html = `<div class="banner mine-turn">Your turn<small>${tip}</small></div>`;
      } else {
        html = `<div class="banner">${S.esc(S.nameOf(st, g.turn))}'s turn</div>`;
      }
    } else {
      html = `<div class="banner">Hand over</div>`;
    }
    if (html !== actionHtml) {
      actionHtml = html;
      $('action').innerHTML = html;
    }
  }

  $('action').addEventListener('click', async (e) => {
    const bidBtn = e.target.closest('[data-bid]');
    if (bidBtn) {
      bidChoice = Number(bidBtn.dataset.bid);
      if (state) renderAction(state);
      return;
    }
    if (e.target.closest('#bidConfirm')) {
      if (bidChoice === null || busy) return;
      busy = true;
      const res = await send('player:bid', { bid: bidChoice });
      busy = false;
      if (res.ok) bidChoice = null;
      return;
    }
    if (e.target.closest('#reclaimBtn')) join();
  });

  // ---------- the full table on the phone ----------
  const boardTrick = new S.TrickView($('btrick'), {
    slot(seat, card) {
      const cw = boardTrick.cw;
      const h = cw * 1.4;
      const xy = [
        [0, 0.55 * h],
        [-1.12 * cw, 0],
        [0, -0.55 * h],
        [1.12 * cw, 0],
      ][relOf(seat)];
      let n = 0;
      for (const ch of card) n += ch.charCodeAt(0);
      return { x: xy[0], y: xy[1], rot: ((n % 7) - 3) * 2 };
    },
    origin(seat, card) {
      if (seat === state.you.seat && lastPlayed && lastPlayed.card === card && Date.now() - lastPlayed.at < 4000) {
        const p = boardTrick.local(lastPlayed.rect);
        return { x: p.x, y: p.y, rot: 0, scale: lastPlayed.rect.width / boardTrick.cw, opacity: 1 };
      }
      const p = boardTrick.local(whoEl(relOf(seat)).getBoundingClientRect());
      return { x: p.x, y: p.y, scale: 0.5, opacity: 0.3 };
    },
    sweepTo(seat) {
      const p = boardTrick.local(whoEl(relOf(seat)).getBoundingClientRect());
      return { x: p.x, y: p.y, scale: 0.3 };
    },
  });

  function sizeBoard() {
    const b = $('board');
    boardTrick.setCardWidth(Math.round(Math.max(34, Math.min(72, b.clientHeight * 0.2, b.clientWidth * 0.15))));
  }

  function renderWho(st) {
    const g = st.game;
    document.querySelectorAll('.who').forEach((el) => {
      const seat = (st.you.seat + Number(el.dataset.rel)) % 4;
      const s = st.seats[seat];
      const active = (g.phase === 'bidding' || g.phase === 'playing') && g.turn === seat;
      let bid = S.bidText(g.bids[seat]);
      if (g.bids[seat] === null && active && g.phase === 'bidding') bid = '…';
      el.className = `who ${S.colorOf(st, seat)}` + (active ? ' turn' : '') + (s && !s.connected ? ' off' : '');
      const tag = s && s.isBot ? ' 🤖' : s && s.botControl ? ' (bot)' : '';
      el.innerHTML =
        `<span class="wn">${g.dealer === seat ? '<i class="dbadge" title="Dealer">D</i>' : ''}${S.esc(meName(st, seat))}${tag}</span>` +
        `<span class="ws">Bid ${bid} · Won <b>${g.tricksWon[seat]}</b></span>`;
    });
  }

  function bumpWho(rel) {
    const b = whoEl(rel).querySelector('.ws b');
    if (!b) return;
    b.classList.remove('bump');
    void b.offsetWidth;
    b.classList.add('bump');
  }

  // Host: tap a player on the table to let a bot cover for them.
  document.querySelectorAll('.who').forEach((el) =>
    el.addEventListener('click', () => {
      if (!state || !state.game || !state.you.isHost) return;
      const seat = (state.you.seat + Number(el.dataset.rel)) % 4;
      const s = state.seats[seat];
      if (seat === state.you.seat || !s || s.isBot) return;
      const msg = s.botControl ? `Give the seat back to ${s.name}?` : `Let a bot play for ${s.name} until they come back?`;
      S.ask(msg).then((ok) => ok && send('room:botControl', { seat, on: !s.botControl }));
    }),
  );

  $('viewBtn').addEventListener('click', () => {
    showTable = !showTable;
    S.store.set('spades.phoneTable', showTable ? '1' : '0');
    if (state && state.game && state.you.seat >= 0) renderGame(state, state);
  });

  // ---------- your hand ----------
  function renderHand(st) {
    const g = st.game;
    const hand = st.you.hand;
    const playable = canPlay(st);
    const legal = new Set(st.you.legal);
    const full = isFull(st);
    if (selected && !hand.includes(selected)) selected = null;
    const W = handEl.clientWidth;
    const H = handEl.clientHeight;

    for (const [c, el] of handEls) {
      if (hand.includes(c)) continue;
      handEls.delete(c);
      const played = g.trick.some((p) => p.card === c) || (g.lastTrick && g.lastTrick.cards.some((p) => p.card === c));
      if (played && full) {
        lastPlayed = { card: c, rect: el.getBoundingClientRect(), at: Date.now() };
        el.remove();
      } else if (played) flyOff(el);
      else el.remove();
    }

    // A new deal: cards drop in from the top (from the table), one after another.
    let k = 0;
    for (const c of hand) {
      if (handEls.has(c)) continue;
      const el = S.cardEl(c);
      el.style.transition = 'none';
      el.style.transform = `translate(${W / 2 - 40}px, ${-H - 160}px) rotate(-10deg)`;
      el.style.opacity = '0';
      el.dataset.delay = String(k++ * 45);
      handEl.appendChild(el);
      handEls.set(c, el);
    }
    void handEl.offsetWidth;
    for (const el of handEls.values()) {
      el.style.transition = '';
      if (el.dataset.delay !== undefined) {
        el.style.transitionDelay = el.dataset.delay + 'ms';
        el.style.opacity = '1';
        delete el.dataset.delay;
        setTimeout(() => (el.style.transitionDelay = ''), 1200);
      }
    }

    handOrder = hand.slice();
    for (const c of hand) {
      const el = handEls.get(c);
      el.classList.toggle('dim', playable && !legal.has(c));
      el.classList.toggle('sel', c === selected);
    }
    layoutHand();
  }

  /** The played card flies up and off the phone, toward the iPad. */
  function flyOff(el) {
    const x = Number(el.dataset.x) || 0;
    const y = Number(el.dataset.y) || 0;
    const rise = handEl.getBoundingClientRect().top + y + 260;
    el.classList.remove('sel', 'dim');
    el.classList.add('fly-off');
    el.style.transitionDelay = '';
    requestAnimationFrame(() => {
      el.style.transform = `translate(${x}px, ${y - rise}px) rotate(${(Math.random() * 24 - 12).toFixed(1)}deg) scale(0.85)`;
      el.style.opacity = '0.1';
    });
    setTimeout(() => el.remove(), 750);
  }

  /** You won the trick: its cards drop in from the top into your pile. */
  function flyInWon(cards) {
    const target = $('wonPile').getBoundingClientRect();
    const w = 62;
    const tx = target.left + target.width / 2 - w / 2;
    const ty = target.top + target.height / 2 - w * 0.7;
    cards.forEach((p, i) => {
      const el = S.cardEl(p.card, 'fly-in');
      el.style.transform = `translate(${window.innerWidth / 2 - w / 2 + (i - 1.5) * 48}px, -150px) rotate(${(i - 1.5) * 12}deg)`;
      document.body.appendChild(el);
      void el.offsetWidth;
      el.style.transition = `transform 0.8s cubic-bezier(0.2, 0.75, 0.3, 1) ${i * 80}ms, opacity 0.25s ease ${i * 80 + 700}ms`;
      el.style.transform = `translate(${tx}px, ${ty}px) rotate(${(i - 1.5) * 6}deg) scale(0.55)`;
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 1400 + i * 80);
    });
    setTimeout(() => {
      if (state && state.game && state.you.seat >= 0) renderMine(state);
      const pile = $('wonPile');
      pile.classList.remove('bump');
      void pile.offsetWidth;
      pile.classList.add('bump');
    }, 950);
  }

  function layoutHand() {
    const els = handOrder.map((c) => handEls.get(c)).filter(Boolean);
    const n = els.length;
    if (!n) return;
    const W = handEl.clientWidth;
    const H = handEl.clientHeight;
    const lift = 18;
    const minOverlap = 0.5; // a lower row may cover the bottom half of the row above
    const visible = 0.42; // at least this much of each overlapped card stays visible
    // Pick 1-3 rows, whichever gives the biggest cards for this screen.
    let best = null;
    for (let r = 1; r <= 3; r++) {
      if (r > 1 && n <= (r - 1) * 4) break;
      const per = Math.ceil(n / r);
      const byWidth = Math.min(132, (W - 8) / (1 + visible * (per - 1)));
      const byHeight = (H - lift - 6) / (1.4 * (1 + minOverlap * (r - 1)));
      const size = Math.min(byWidth, byHeight);
      if (!best || size > best.size + 2) best = { rows: r, size };
    }
    const rows = best.rows;
    const w = Math.max(44, best.size);
    const h = w * 1.4;
    const perRow = [];
    for (let r = 0; r < rows; r++) perRow.push(Math.floor(n / rows) + (r < n % rows ? 1 : 0));
    // On tall screens, spread the rows apart so whole cards show.
    const overlapY = rows > 1 ? Math.min(1.04, Math.max(minOverlap, (H - lift - 6 - h) / (h * (rows - 1)))) : 0;
    handEl.style.setProperty('--hw', w + 'px');
    const total = h + (rows - 1) * h * overlapY;
    const top = Math.max(lift, H - total - 4); // keep the cards near the thumb
    let k = 0;
    perRow.forEach((cnt, r) => {
      const step = cnt > 1 ? Math.min(w + 6, (W - w) / (cnt - 1)) : 0;
      const x0 = (W - (w + step * (cnt - 1))) / 2;
      for (let i = 0; i < cnt; i++, k++) {
        const el = els[k];
        const sel = el.dataset.card === selected;
        const x = x0 + i * step;
        const y = top + r * h * overlapY - (sel ? lift : 0);
        el.dataset.x = String(x);
        el.dataset.y = String(y);
        el.style.transform = `translate(${x}px, ${y}px)`;
        el.style.zIndex = String(r * 20 + i + (sel ? 100 : 0));
      }
    });
  }

  function illegalReason(g) {
    if (g.trick.length === 0) return "Spades aren't broken yet. Lead another suit.";
    return `You must follow ${S.SUIT_WORD[g.trick[0].card[1]]}.`;
  }

  handEl.addEventListener('click', async (e) => {
    const el = e.target.closest('.card');
    if (!el || el.classList.contains('fly-off') || !state || !state.game) return;
    const card = el.dataset.card;
    const playable = canPlay(state);
    if (playable && !state.you.legal.includes(card)) {
      S.toast(illegalReason(state.game));
      return;
    }
    if (playable && selected === card) {
      if (busy) return;
      busy = true;
      const res = await send('player:play', { card });
      busy = false;
      if (res.ok) selected = null;
      return;
    }
    selected = selected === card ? null : card;
    renderHand(state);
  });

  // ---------- quitting: everyone has to agree ----------
  $('quitBtn').addEventListener('click', () => {
    if (!state || state.quitVote) return;
    S.ask('Ask everyone to quit this game? It only ends if every player agrees.', 'Ask to quit').then((ok) => ok && send('game:quit'));
  });

  function renderVote(st) {
    const v = st.phase !== 'lobby' ? st.quitVote : null;
    const me = st.you.seat;
    const key = v ? JSON.stringify(v) + ':' + me : '';
    if (key === voteKey) return;
    if (v && !voteKey && v.by !== me) Sound.play('alert');
    voteKey = key;
    $('voteSheet').classList.toggle('hidden', !v);
    if (!v) return;
    const by = v.by < 0 ? 'The table' : v.by === me ? 'You' : S.nameOf(st, v.by);
    const list =
      `<ul class="vote">` +
      v.voters
        .map((s) => {
          const yes = v.agreed.includes(s);
          return `<li class="${yes ? 'yes' : ''}">${yes ? '✓ ' : '… '}${S.esc(meName(st, s))}</li>`;
        })
        .join('') +
      `</ul>`;
    let html;
    if (v.agreed.includes(me)) {
      html =
        `<h2>Waiting for everyone…</h2><p class="muted">The game only ends if every player agrees to quit.</p>${list}` +
        `<button class="btn" id="voteNo" type="button">Keep playing</button>`;
    } else if (v.voters.includes(me)) {
      html =
        `<h2>${S.esc(by)} ${by === 'You' ? 'want' : 'wants'} to quit</h2><p class="muted">Quit this game? It only ends if everyone agrees.</p>${list}` +
        `<button class="btn danger" id="voteYes" type="button">Yes, quit</button>` +
        `<button class="btn primary" id="voteNo" type="button">Keep playing</button>`;
    } else {
      html = `<h2>${S.esc(by)} ${by === 'You' ? 'want' : 'wants'} to quit</h2>${list}`;
    }
    $('votePanel').className = 'sheet-panel';
    $('votePanel').innerHTML = html;
    const yes = $('voteYes');
    const no = $('voteNo');
    if (yes) yes.onclick = () => send('game:quitVote', { agree: true });
    if (no) no.onclick = () => send('game:quitVote', { agree: false });
  }

  // ---------- results ----------
  function renderSheet(st) {
    const g = st.game;
    const showIt = g.phase === 'handOver' || g.phase === 'gameOver';
    const key = showIt ? `${g.phase}:${g.handNumber}` : null;
    if (key === sheetKey) return;
    sheetKey = key;
    $('sheet').classList.toggle('hidden', !showIt);
    if (!showIt) return;

    const me = st.you.seat;
    const myUnit = S.unitOf(st, me);
    const solo = g.units.length === 4;
    const r = g.lastHandResult;
    const over = g.phase === 'gameOver';
    const order = [myUnit].concat(g.units.map((_, u) => u).filter((u) => u !== myUnit));
    const label = (u) => (u === myUnit ? (solo ? 'You' : 'Us') : solo ? S.unitName(st, u) : 'Them');
    const rows = order
      .map((u) => {
        const ur = r.units[u];
        return (
          `<span class="n c${u}">${S.esc(label(u))}</span>` +
          `<span class="p ${ur.points >= 0 ? 'pos' : 'neg'}">${S.signed(ur.points)}</span>` +
          `<span class="s">${ur.score}</span>`
        );
      })
      .join('');
    const notes = [];
    for (const u of order) {
      const ur = r.units[u];
      const who = label(u);
      if (ur.made === true) notes.push(`✅ ${who}: made ${ur.bid} (took ${ur.contractTricks})`);
      if (ur.made === false) notes.push(`❌ ${who}: set, bid ${ur.bid}, took ${ur.contractTricks}`);
      for (const n of ur.nils) notes.push(`${n.made ? '🎯' : '💥'} ${meName(st, n.seat)} Nil ${n.made ? '+100' : '−100'}`);
      if (ur.bagPenalty) notes.push(`🎒 ${who}: 10 bags, −${ur.bagPenalty}`);
    }
    let title;
    if (over) title = g.winner === myUnit ? '🏆 You won!' : `${S.unitName(st, g.winner)} won`;
    else title = `Hand ${r.handNumber} results`;

    const panel = $('sheetPanel');
    panel.className = 'sheet-panel' + (over && g.winner === myUnit ? ' win' : '');
    panel.innerHTML =
      `<h2>${S.esc(title)}</h2>` +
      `<div class="res">${rows}</div>` +
      `<ul class="res-notes">${notes.map((n) => `<li>${S.esc(n)}</li>`).join('')}</ul>` +
      (over
        ? `<button class="btn primary big" id="againBtn" type="button">Play again</button>`
        : `<button class="btn primary big" id="nextBtn" type="button">Next hand</button>`);
    if (over) $('againBtn').onclick = () => send('game:playAgain');
    else $('nextBtn').onclick = () => send('game:next');
  }

  // ---------- resize ----------
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (state && state.game && state.you.seat >= 0) {
        layoutHand();
        if (isFull(state)) {
          sizeBoard();
          boardTrick.relayout();
        }
      }
    }, 80);
  });
})();
