'use strict';

// Rooms: who sits where, settings, host, quit votes, timers for bots and trick collection.
// Everything that reaches a screen goes through Room.view(), which only ever
// includes the hand of the player asking for it.

const crypto = require('crypto');
const { SpadesGame, GameError, isCard } = require('./game');
const { botBid, botPlay } = require('./bot');

const CODE_LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // no I or O (look like 1 and 0)
const SEAT_NAMES = ['North', 'East', 'South', 'West'];
const TARGETS = [250, 300, 500];
const NAME_MAX = 16;
const IDLE_MS = 3 * 60 * 60 * 1000; // empty rooms are deleted after 3 hours
const MAX_ROOMS = 500;
const QUIT_VOTE_MS = 60 * 1000;

function randomCode() {
  let code = '';
  for (let i = 0; i < 4; i++) code += CODE_LETTERS[crypto.randomInt(CODE_LETTERS.length)];
  return code;
}

function cleanName(name) {
  const n = String(name ?? '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, NAME_MAX);
  if (!n) throw new GameError('Enter your name first.');
  return n;
}

function seatIndex(seat) {
  if (!Number.isInteger(seat) || seat < 0 || seat > 3) throw new GameError('Unknown seat.');
  return seat;
}

class Room {
  /**
   * @param {string} code
   * @param {'table'|'phones'} mode  'table': an iPad shows the table. 'phones': no iPad, phones show everything.
   * @param {string|null} hostToken  the player who created a phones-only room
   * @param {{onChange:(room:Room)=>void, botDelayMs:number, trickPauseMs:number, gameOpts?:object}} opts
   */
  constructor(code, mode, hostToken, opts) {
    this.code = code;
    this.mode = mode;
    this.hostToken = hostToken;
    this.opts = opts;
    this.seats = [null, null, null, null]; // {token, name, isBot, botControl}
    this.settings = { target: 500, nil: true, bagPenalty: true, fillBots: true, teams: true };
    this.game = null;
    this.quitVote = null; // {by, agreed:Set<seat>, timer}
    this.sockets = new Set();
    this.botTimer = null;
    this.collectTimer = null;
    this.lastActivity = Date.now();
  }

  get phase() {
    return this.game ? this.game.phase : 'lobby';
  }

  changed() {
    this.lastActivity = Date.now();
    this.opts.onChange(this);
  }

  seatOf(token) {
    if (!token) return -1;
    return this.seats.findIndex((s) => s && !s.isBot && s.token === token);
  }

  tokenConnected(token) {
    for (const sock of this.sockets) {
      if (sock.data.role === 'player' && sock.data.token === token) return true;
    }
    return false;
  }

  isConnected(i) {
    const s = this.seats[i];
    if (!s) return false;
    return s.isBot || this.tokenConnected(s.token);
  }

  hasTable() {
    for (const sock of this.sockets) if (sock.data.role === 'table') return true;
    return false;
  }

  /**
   * Which player's phone has the host controls (settings, start, bots)? Null means the
   * iPad table has them. If the host's phone is gone, the first connected player takes over.
   */
  hostTokenNow() {
    if (this.mode === 'table' && this.hasTable()) return null;
    if (this.hostToken && this.tokenConnected(this.hostToken)) return this.hostToken;
    const first = this.seats.find((s, i) => s && !s.isBot && this.isConnected(i));
    return first ? first.token : this.hostToken;
  }

  canControl(role, token) {
    if (role === 'table') return true;
    const host = this.hostTokenNow();
    return !!token && token === host;
  }

  requireControl(role, token) {
    if (!this.canControl(role, token)) {
      throw new GameError(this.mode === 'table' ? 'Only the table screen can do that.' : 'Only the host can do that.');
    }
  }

  requireGame() {
    if (!this.game) throw new GameError("The game hasn't started yet.");
    return this.game;
  }

  requireSeat(token) {
    const seat = this.seatOf(token);
    if (seat < 0) throw new GameError("You don't have a seat in this game.");
    return seat;
  }

  // ---- lobby ----

  sit(token, name, seat) {
    if (this.game) throw new GameError('The game has already started.');
    seatIndex(seat);
    const clean = cleanName(name);
    const taken = this.seats[seat];
    if (taken && taken.token !== token) throw new GameError(`${SEAT_NAMES[seat]} is already taken.`);
    const current = this.seatOf(token);
    if (current >= 0) this.seats[current] = null;
    this.seats[seat] = { token, name: clean, isBot: false, botControl: false };
    this.changed();
  }

  leave(token) {
    if (this.game) throw new GameError("You can't leave your seat during a game.");
    const seat = this.seatOf(token);
    if (seat >= 0) {
      this.seats[seat] = null;
      this.changed();
    }
  }

  kick(seat) {
    if (this.game) throw new GameError("Players can't be removed during a game.");
    this.seats[seatIndex(seat)] = null;
    this.changed();
  }

  updateSettings(patch) {
    if (this.game) throw new GameError('Settings can only change before the game starts.');
    const next = { ...this.settings };
    if (patch.target !== undefined) {
      if (!TARGETS.includes(patch.target)) throw new GameError('Target must be 250, 300 or 500.');
      next.target = patch.target;
    }
    for (const key of ['nil', 'bagPenalty', 'fillBots', 'teams']) {
      if (patch[key] !== undefined) {
        if (typeof patch[key] !== 'boolean') throw new GameError(`Bad value for ${key}.`);
        next[key] = patch[key];
      }
    }
    this.settings = next;
    this.changed();
  }

  start() {
    if (this.game) throw new GameError('The game has already started.');
    const empty = [0, 1, 2, 3].filter((i) => !this.seats[i]);
    if (empty.length && !this.settings.fillBots) {
      throw new GameError('All 4 seats need a player, or turn on bots.');
    }
    for (const i of empty) {
      this.seats[i] = { token: null, name: `Bot ${SEAT_NAMES[i]}`, isBot: true, botControl: false };
    }
    const { target, nil, bagPenalty, teams } = this.settings;
    this.game = new SpadesGame({ target, nil, bagPenalty, teams }, this.opts.gameOpts);
    this.changed();
    this.scheduleBot();
  }

  // ---- game actions ----

  bid(token, bid) {
    const seat = this.requireSeat(token);
    this.requireGame().placeBid(seat, bid);
    this.changed();
    this.scheduleBot();
  }

  play(token, card) {
    if (!isCard(card)) throw new GameError('Unknown card.');
    const seat = this.requireSeat(token);
    this.requireGame();
    this.applyPlay(seat, card);
  }

  applyPlay(seat, card) {
    const trickDone = this.game.playCard(seat, card);
    if (trickDone) this.scheduleCollect();
    this.changed();
    this.scheduleBot();
  }

  nextHand() {
    this.requireGame().nextHand();
    this.changed();
    this.scheduleBot();
  }

  playAgain() {
    const game = this.requireGame();
    if (game.phase !== 'gameOver') throw new GameError('The game is still going.');
    this.resetToLobby();
  }

  /** Back to the lobby. Bots leave, players keep their seats. */
  resetToLobby() {
    this.clearTimers();
    this.clearQuitVote();
    this.game = null;
    this.seats = this.seats.map((s) => (s && !s.isBot ? { ...s, botControl: false } : null));
    this.changed();
  }

  /** Let a bot play for a human (e.g. their phone died), or hand the seat back. */
  setBotControl(seat, on) {
    this.requireGame();
    const s = this.seats[seatIndex(seat)];
    if (!s || s.isBot) throw new GameError('That seat is already a bot.');
    s.botControl = !!on;
    if (!this.checkQuit()) this.changed();
    this.scheduleBot();
  }

  /** A returning player takes their seat back from a bot. */
  reclaim(token) {
    const seat = this.seatOf(token);
    if (seat >= 0 && this.seats[seat].botControl) {
      this.seats[seat].botControl = false;
      this.scheduleBot();
    }
  }

  // ---- quitting: only when every player agrees ----

  /** Players whose agreement is needed: humans who are here and not covered by a bot. */
  quitVoters() {
    return [0, 1, 2, 3].filter((i) => {
      const s = this.seats[i];
      return s && !s.isBot && !s.botControl && this.isConnected(i);
    });
  }

  requestQuit(role, token) {
    this.requireGame();
    if (role === 'player') this.requireSeat(token);
    if (!this.quitVote) {
      this.quitVote = { by: role === 'player' ? this.seatOf(token) : -1, agreed: new Set(), timer: null };
      this.quitVote.timer = setTimeout(() => this.cancelQuit(), QUIT_VOTE_MS);
    }
    if (role === 'player') this.quitVote.agreed.add(this.seatOf(token));
    if (!this.checkQuit()) this.changed();
  }

  voteQuit(token, agree) {
    const seat = this.requireSeat(token);
    if (!this.quitVote) throw new GameError('Nobody has asked to quit.');
    if (!agree) return this.cancelQuit();
    this.quitVote.agreed.add(seat);
    if (!this.checkQuit()) this.changed();
  }

  /** Ends the game if everyone needed has agreed. Returns true if it did. */
  checkQuit() {
    if (!this.quitVote) return false;
    if (this.quitVoters().every((i) => this.quitVote.agreed.has(i))) {
      this.resetToLobby();
      return true;
    }
    return false;
  }

  cancelQuit() {
    if (!this.quitVote) return;
    this.clearQuitVote();
    this.changed();
  }

  clearQuitVote() {
    if (this.quitVote) clearTimeout(this.quitVote.timer);
    this.quitVote = null;
  }

  // ---- timers ----

  isBotSeat(i) {
    const s = this.seats[i];
    return !!s && (s.isBot || s.botControl);
  }

  scheduleCollect() {
    clearTimeout(this.collectTimer);
    const game = this.game;
    this.collectTimer = setTimeout(() => {
      this.collectTimer = null;
      if (this.game !== game || game.trickWinner === null) return;
      game.collectTrick();
      this.changed();
      this.scheduleBot();
    }, this.opts.trickPauseMs);
  }

  scheduleBot() {
    clearTimeout(this.botTimer);
    this.botTimer = null;
    const game = this.game;
    if (!game || (game.phase !== 'bidding' && game.phase !== 'playing')) return;
    if (game.turn === null || !this.isBotSeat(game.turn)) return;
    const seat = game.turn;
    const delay = Math.round(this.opts.botDelayMs * (0.7 + Math.random() * 0.6));
    this.botTimer = setTimeout(() => {
      this.botTimer = null;
      if (this.game !== game || game.turn !== seat || !this.isBotSeat(seat)) return;
      try {
        if (game.phase === 'bidding') {
          game.placeBid(seat, botBid(game.hands[seat]));
          this.changed();
          this.scheduleBot();
        } else if (game.phase === 'playing') {
          const card = botPlay({
            seat,
            hand: game.hands[seat],
            trick: game.trick,
            spadesBroken: game.spadesBroken,
            bids: game.bids,
            teams: game.settings.teams,
          });
          this.applyPlay(seat, card);
        }
      } catch (err) {
        console.error(`[room ${this.code}] bot error`, err);
      }
    }, delay);
  }

  clearTimers() {
    clearTimeout(this.botTimer);
    clearTimeout(this.collectTimer);
    this.botTimer = null;
    this.collectTimer = null;
  }

  destroy() {
    this.clearTimers();
    this.clearQuitVote();
  }

  // ---- what each screen gets ----

  view(role, token) {
    const game = this.game;
    const host = this.hostTokenNow();
    const v = {
      code: this.code,
      mode: this.mode,
      phase: this.phase,
      settings: this.settings,
      seats: this.seats.map(
        (s, i) =>
          s && {
            name: s.name,
            isBot: s.isBot,
            botControl: s.botControl,
            connected: this.isConnected(i),
          },
      ),
      tableConnected: this.hasTable(),
      hostSeat: host ? this.seatOf(host) : -1,
      quitVote: this.quitVote && {
        by: this.quitVote.by,
        agreed: [...this.quitVote.agreed],
        voters: this.quitVoters(),
      },
      game: game ? game.publicState() : null,
    };
    if (role === 'player') {
      const seat = this.seatOf(token);
      v.you = {
        seat,
        isHost: this.canControl('player', token),
        hand: game && seat >= 0 ? game.hands[seat] : [],
        legal: game && seat >= 0 ? game.legalFor(seat) : [],
      };
    }
    return v;
  }
}

class RoomManager {
  constructor(opts) {
    this.opts = opts;
    this.rooms = new Map();
    this.cleanupTimer = setInterval(() => this.cleanup(), 10 * 60 * 1000);
    if (this.cleanupTimer.unref) this.cleanupTimer.unref(); // (not available in browsers)
  }

  create(mode = 'table', hostToken = null) {
    if (this.rooms.size >= MAX_ROOMS) this.cleanup(Date.now(), 15 * 60 * 1000);
    if (this.rooms.size >= MAX_ROOMS) throw new GameError('The server is full right now. Try again later.');
    let code;
    do code = randomCode();
    while (this.rooms.has(code));
    const room = new Room(code, mode, hostToken, this.opts);
    this.rooms.set(code, room);
    return room;
  }

  get(code) {
    return this.rooms.get(String(code ?? '').trim().toUpperCase());
  }

  cleanup(now = Date.now(), idleMs = IDLE_MS) {
    for (const [code, room] of this.rooms) {
      if (room.sockets.size === 0 && now - room.lastActivity > idleMs) {
        room.destroy();
        this.rooms.delete(code);
      }
    }
  }

  close() {
    clearInterval(this.cleanupTimer);
    for (const room of this.rooms.values()) room.destroy();
    this.rooms.clear();
  }
}

module.exports = { Room, RoomManager, SEAT_NAMES, cleanName };
